"""
Super Bollinger Bands Indicator
Enhanced Bollinger Bands with squeeze detection and volatility analysis.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class BollingerSignal:
    """Enhanced Bollinger Bands signal data structure with rejection patterns."""
    signal: str  # 'BUY', 'SELL', 'HOLD', 'BREAKOUT_BUY', 'BREAKOUT_SELL'
    strength: float  # Signal strength 0-1
    price_position: float  # Position relative to bands (-1 to 1)
    bandwidth: float  # Band width as percentage
    squeeze_state: str  # 'SQUEEZE', 'EXPANSION', 'NORMAL'
    volatility_trend: str  # 'INCREASING', 'DECREASING', 'STABLE'
    confidence: float
    rejection_pattern: bool  # Price rejecting band levels
    band_touch: str  # 'UPPER', 'LOWER', 'MIDDLE', 'NONE'
    reversal_confirmed: bool  # Price reversal inside bands confirmed


class SuperBollinger:
    """Super Bollinger Bands indicator implementation."""
    
    def __init__(self, config):
        self.length = config.length
        self.multiplier = config.multiplier
        self.ma_type = config.ma_type
        self.squeeze_threshold = config.squeeze_threshold
        self.expansion_threshold = config.expansion_threshold
    
    def calculate_moving_average(self, data: pd.Series, period: int, ma_type: str) -> pd.Series:
        """Calculate moving average based on type."""
        if ma_type == "SMA":
            return data.rolling(window=period, min_periods=1).mean()
        elif ma_type == "EMA":
            return data.ewm(span=period).mean()
        elif ma_type == "SMMA" or ma_type == "RMA":
            # Smoothed Moving Average (RMA)
            alpha = 1.0 / period
            return data.ewm(alpha=alpha).mean()
        elif ma_type == "WMA":
            # Weighted Moving Average
            weights = np.arange(1, period + 1)
            return data.rolling(window=period).apply(
                lambda x: np.dot(x, weights) / weights.sum(), raw=True
            )
        else:
            # Default to SMA
            return data.rolling(window=period, min_periods=1).mean()
    
    def calculate_bollinger_bands(self, data: pd.Series) -> tuple:
        """Calculate Bollinger Bands components."""
        # Calculate middle line (moving average)
        middle = self.calculate_moving_average(data, self.length, self.ma_type)
        
        # Calculate standard deviation
        std_dev = data.rolling(window=self.length, min_periods=1).std()
        
        # Calculate upper and lower bands
        upper = middle + (std_dev * self.multiplier)
        lower = middle - (std_dev * self.multiplier)
        
        return upper, middle, lower, std_dev
    
    def calculate_bandwidth(self, upper: pd.Series, lower: pd.Series, middle: pd.Series) -> pd.Series:
        """Calculate Bollinger Band width as percentage."""
        bandwidth = ((upper - lower) / middle) * 100
        return bandwidth
    
    def calculate_percent_b(self, price: pd.Series, upper: pd.Series, lower: pd.Series) -> pd.Series:
        """Calculate %B (price position within bands)."""
        percent_b = (price - lower) / (upper - lower)
        return percent_b
    
    def detect_squeeze(self, bandwidth: pd.Series) -> pd.Series:
        """Detect Bollinger Band squeeze conditions."""
        # Calculate rolling statistics for bandwidth
        rolling_mean = bandwidth.rolling(window=20, min_periods=1).mean()
        rolling_std = bandwidth.rolling(window=20, min_periods=1).std()
        
        squeeze_state = pd.Series(index=bandwidth.index, dtype=str)
        
        # Squeeze: bandwidth significantly below average
        squeeze_threshold = rolling_mean - (rolling_std * self.squeeze_threshold)
        squeeze_condition = bandwidth < squeeze_threshold
        
        # Expansion: bandwidth significantly above average
        expansion_threshold = rolling_mean + (rolling_std * self.expansion_threshold)
        expansion_condition = bandwidth > expansion_threshold
        
        squeeze_state[squeeze_condition] = 'SQUEEZE'
        squeeze_state[expansion_condition] = 'EXPANSION'
        squeeze_state.fillna('NORMAL', inplace=True)
        
        return squeeze_state
    
    def calculate_volatility_trend(self, bandwidth: pd.Series) -> pd.Series:
        """Calculate volatility trend direction."""
        # Calculate rate of change in bandwidth
        bandwidth_roc = bandwidth.pct_change(periods=5).rolling(window=3).mean()
        
        volatility_trend = pd.Series(index=bandwidth.index, dtype=str)
        
        volatility_trend[bandwidth_roc > 0.05] = 'INCREASING'
        volatility_trend[bandwidth_roc < -0.05] = 'DECREASING'
        volatility_trend.fillna('STABLE', inplace=True)
        
        return volatility_trend
    
    def calculate_price_position(self, price: pd.Series, upper: pd.Series, 
                               middle: pd.Series, lower: pd.Series) -> pd.Series:
        """Calculate normalized price position relative to bands."""
        # Convert %B to position from -1 (at lower band) to 1 (at upper band)
        percent_b = self.calculate_percent_b(price, upper, lower)
        position = (percent_b - 0.5) * 2  # Scale to -1 to 1
        return position
    
    def calculate_signal_strength(self, price_position: pd.Series, bandwidth: pd.Series,
                                 squeeze_state: pd.Series, volatility_trend: pd.Series) -> pd.Series:
        """Calculate signal strength based on multiple factors."""
        strength = pd.Series(index=price_position.index, dtype=float)
        
        # Position strength (stronger at extremes)
        position_strength = abs(price_position)
        
        # Volatility strength (stronger during expansions)
        volatility_strength = pd.Series(index=bandwidth.index, dtype=float)
        volatility_strength[squeeze_state == 'EXPANSION'] = 0.8
        volatility_strength[squeeze_state == 'SQUEEZE'] = 0.3
        volatility_strength.fillna(0.5, inplace=True)
        
        # Trend strength
        trend_strength = pd.Series(index=bandwidth.index, dtype=float)
        trend_strength[volatility_trend == 'INCREASING'] = 0.7
        trend_strength[volatility_trend == 'DECREASING'] = 0.4
        trend_strength.fillna(0.5, inplace=True)
        
        # Combine factors
        strength = (position_strength + volatility_strength + trend_strength) / 3
        strength = np.clip(strength, 0, 1)
        
        return strength
    
    def detect_band_touch(self, price: pd.Series, upper: pd.Series, lower: pd.Series, middle: pd.Series) -> pd.Series:
        """Detect when price touches Bollinger Band levels."""
        band_touch = pd.Series(index=price.index, dtype=str, default='NONE')
        
        # Define touch threshold (price within 0.1% of band)
        touch_threshold = 0.001
        
        for i in range(len(price)):
            upper_distance = abs(price.iloc[i] - upper.iloc[i]) / upper.iloc[i]
            lower_distance = abs(price.iloc[i] - lower.iloc[i]) / lower.iloc[i]
            middle_distance = abs(price.iloc[i] - middle.iloc[i]) / middle.iloc[i]
            
            if upper_distance <= touch_threshold:
                band_touch.iloc[i] = 'UPPER'
            elif lower_distance <= touch_threshold:
                band_touch.iloc[i] = 'LOWER'
            elif middle_distance <= touch_threshold:
                band_touch.iloc[i] = 'MIDDLE'
            else:
                band_touch.iloc[i] = 'NONE'
        
        return band_touch
    
    def detect_rejection_pattern(self, price: pd.Series, upper: pd.Series, lower: pd.Series) -> pd.Series:
        """Detect rejection patterns at Bollinger Band levels."""
        rejections = pd.Series(index=price.index, dtype=bool, default=False)
        
        for i in range(2, len(price)):
            # Check for rejection at upper band
            if (price.iloc[i-2] >= upper.iloc[i-2] and  # Price was at/above upper band
                price.iloc[i-1] >= upper.iloc[i-1] and  # Price stayed at upper band
                price.iloc[i] < upper.iloc[i]):          # Price moved back inside bands
                rejections.iloc[i] = True
            
            # Check for rejection at lower band
            elif (price.iloc[i-2] <= lower.iloc[i-2] and  # Price was at/below lower band
                  price.iloc[i-1] <= lower.iloc[i-1] and  # Price stayed at lower band
                  price.iloc[i] > lower.iloc[i]):          # Price moved back inside bands
                rejections.iloc[i] = True
        
        return rejections
    
    def detect_reversal_confirmation(self, price: pd.Series, upper: pd.Series, lower: pd.Series, 
                                   rejection_pattern: pd.Series) -> pd.Series:
        """Confirm price reversal inside Bollinger Bands after rejection."""
        confirmations = pd.Series(index=price.index, dtype=bool, default=False)
        
        for i in range(3, len(price)):
            if rejection_pattern.iloc[i-1]:  # Previous bar had rejection
                # For upper band rejection (bearish reversal)
                if price.iloc[i-2] >= upper.iloc[i-2]:
                    # Confirm if price continues to move inside bands
                    if (price.iloc[i] < price.iloc[i-1] and 
                        price.iloc[i] < upper.iloc[i] * 0.98):  # 2% inside upper band
                        confirmations.iloc[i] = True
                
                # For lower band rejection (bullish reversal)
                elif price.iloc[i-2] <= lower.iloc[i-2]:
                    # Confirm if price continues to move inside bands
                    if (price.iloc[i] > price.iloc[i-1] and 
                        price.iloc[i] > lower.iloc[i] * 1.02):  # 2% above lower band
                        confirmations.iloc[i] = True
        
        return confirmations
    
    def generate_signals(self, price: pd.Series, upper: pd.Series, middle: pd.Series,
                        lower: pd.Series, price_position: pd.Series, squeeze_state: pd.Series,
                        volatility_trend: pd.Series, strength: pd.Series) -> pd.Series:
        """Generate enhanced buy/sell/hold signals with rejection pattern detection."""
        signals = pd.Series(index=price.index, dtype=str)
        signals.fillna('HOLD', inplace=True)
        
        # Detect rejection patterns and confirmations
        rejections = self.detect_rejection_pattern(price, upper, lower)
        confirmations = self.detect_reversal_confirmation(price, upper, lower, rejections)
        band_touches = self.detect_band_touch(price, upper, lower, middle)
        
        for i in range(len(price)):
            # Buy signal conditions based on README requirements
            # 3. Price touches lower Bollinger Band with rejection
            lower_band_rejection = (band_touches.iloc[i] == 'LOWER' and rejections.iloc[i])
            
            # 4. Confirmed when price reverses inside BB
            lower_reversal_confirmed = (confirmations.iloc[i] and 
                                      price.iloc[i-2] <= lower.iloc[i-2] if i >= 2 else False)
            
            # Additional buy conditions
            oversold_expansion = (price_position.iloc[i] < -0.8 and squeeze_state.iloc[i] == 'EXPANSION')
            
            if lower_band_rejection or lower_reversal_confirmed or oversold_expansion:
                if (squeeze_state.iloc[i] == 'EXPANSION' and 
                    volatility_trend.iloc[i] == 'INCREASING' and 
                    strength.iloc[i] > 0.7):
                    signals.iloc[i] = 'STRONG_BUY'
                elif rejections.iloc[i] and confirmations.iloc[i]:
                    signals.iloc[i] = 'BUY'
                elif oversold_expansion:
                    signals.iloc[i] = 'BUY'
            
            # Sell signal conditions based on README requirements  
            # 3. Price touches upper Bollinger Band with rejection
            upper_band_rejection = (band_touches.iloc[i] == 'UPPER' and rejections.iloc[i])
            
            # 4. Confirmed when price reverses inside BB
            upper_reversal_confirmed = (confirmations.iloc[i] and 
                                      price.iloc[i-2] >= upper.iloc[i-2] if i >= 2 else False)
            
            # Additional sell conditions
            overbought_expansion = (price_position.iloc[i] > 0.8 and squeeze_state.iloc[i] == 'EXPANSION')
            
            if upper_band_rejection or upper_reversal_confirmed or overbought_expansion:
                if (squeeze_state.iloc[i] == 'EXPANSION' and 
                    volatility_trend.iloc[i] == 'INCREASING' and 
                    strength.iloc[i] > 0.7):
                    signals.iloc[i] = 'STRONG_SELL'
                elif rejections.iloc[i] and confirmations.iloc[i]:
                    signals.iloc[i] = 'SELL'
                elif overbought_expansion:
                    signals.iloc[i] = 'SELL'
            
            # Squeeze breakout signals
            if i > 0:
                squeeze_breakout_up = (squeeze_state.iloc[i-1] == 'SQUEEZE' and 
                                     squeeze_state.iloc[i] == 'EXPANSION' and 
                                     price.iloc[i] > middle.iloc[i])
                
                squeeze_breakout_down = (squeeze_state.iloc[i-1] == 'SQUEEZE' and 
                                       squeeze_state.iloc[i] == 'EXPANSION' and 
                                       price.iloc[i] < middle.iloc[i])
                
                if squeeze_breakout_up:
                    signals.iloc[i] = 'BREAKOUT_BUY'
                elif squeeze_breakout_down:
                    signals.iloc[i] = 'BREAKOUT_SELL'
        
        return signals
    
    def calculate(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate Super Bollinger Bands indicator and generate signals.
        
        Args:
            data: DataFrame with OHLCV data
            
        Returns:
            Dictionary containing Bollinger signals and components
        """
        if len(data) < self.length:
            return {
                'signals': pd.Series(dtype=str),
                'upper': pd.Series(dtype=float),
                'middle': pd.Series(dtype=float),
                'lower': pd.Series(dtype=float),
                'bandwidth': pd.Series(dtype=float),
                'percent_b': pd.Series(dtype=float),
                'price_position': pd.Series(dtype=float),
                'squeeze_state': pd.Series(dtype=str),
                'volatility_trend': pd.Series(dtype=str),
                'strength': pd.Series(dtype=float),
                'latest_signal': None
            }
        
        # Calculate Bollinger Bands
        upper, middle, lower, std_dev = self.calculate_bollinger_bands(data['close'])
        
        # Calculate additional metrics
        bandwidth = self.calculate_bandwidth(upper, lower, middle)
        percent_b = self.calculate_percent_b(data['close'], upper, lower)
        price_position = self.calculate_price_position(data['close'], upper, middle, lower)
        
        # Detect market conditions
        squeeze_state = self.detect_squeeze(bandwidth)
        volatility_trend = self.calculate_volatility_trend(bandwidth)
        
        # Calculate signal strength
        strength = self.calculate_signal_strength(
            price_position, bandwidth, squeeze_state, volatility_trend
        )
        
        # Generate trading signals
        signals = self.generate_signals(
            data['close'], upper, middle, lower, price_position,
            squeeze_state, volatility_trend, strength
        )
        
        # Get latest signal data with enhanced rejection pattern information
        latest_signal = None
        if len(signals) > 0:
            # Get latest rejection and confirmation data
            rejections = self.detect_rejection_pattern(data['close'], upper, lower)
            confirmations = self.detect_reversal_confirmation(data['close'], upper, lower, rejections)
            band_touches = self.detect_band_touch(data['close'], upper, lower, middle)
            
            latest_signal = BollingerSignal(
                signal=signals.iloc[-1],
                strength=strength.iloc[-1] if len(strength) > 0 else 0.0,
                price_position=price_position.iloc[-1] if len(price_position) > 0 else 0.0,
                bandwidth=bandwidth.iloc[-1] if len(bandwidth) > 0 else 0.0,
                squeeze_state=squeeze_state.iloc[-1] if len(squeeze_state) > 0 else 'NORMAL',
                volatility_trend=volatility_trend.iloc[-1] if len(volatility_trend) > 0 else 'STABLE',
                confidence=min(strength.iloc[-1] * 100, 100) if len(strength) > 0 else 0.0,
                rejection_pattern=rejections.iloc[-1] if len(rejections) > 0 else False,
                band_touch=band_touches.iloc[-1] if len(band_touches) > 0 else 'NONE',
                reversal_confirmed=confirmations.iloc[-1] if len(confirmations) > 0 else False
            )
        
        return {
            'signals': signals,
            'upper': upper,
            'middle': middle,
            'lower': lower,
            'bandwidth': bandwidth,
            'percent_b': percent_b,
            'price_position': price_position,
            'squeeze_state': squeeze_state,
            'volatility_trend': volatility_trend,
            'strength': strength,
            'latest_signal': latest_signal
        }
    
    def get_signal_description(self, signal: str) -> str:
        """Get human-readable description of signal."""
        descriptions = {
            'STRONG_BUY': 'Strong bullish signal with high volatility',
            'BUY': 'Bullish signal at lower band',
            'BREAKOUT_BUY': 'Bullish breakout from squeeze',
            'HOLD': 'Neutral signal, maintain current position',
            'SELL': 'Bearish signal at upper band',
            'BREAKOUT_SELL': 'Bearish breakout from squeeze',
            'STRONG_SELL': 'Strong bearish signal with high volatility'
        }
        return descriptions.get(signal, 'Unknown signal')
