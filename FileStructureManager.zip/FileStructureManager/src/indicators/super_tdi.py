"""
Super TDI (Traders Dynamic Index) Indicator
Advanced implementation of TDI with multiple components for trend and momentum analysis.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class TDISignal:
    """Enhanced TDI signal data structure with zone detection."""
    signal: str  # 'BUY', 'SELL', 'HOLD', 'STRONG_BUY', 'STRONG_SELL'
    strength: float  # Signal strength 0-1
    rsi_value: float
    rsi_ma: float
    rsi_signal: float
    volatility_band_upper: float
    volatility_band_lower: float
    momentum: float
    trend_direction: str
    confidence: float
    zone: str  # 'HARD_BUY', 'SOFT_BUY', 'NO_TRADE', 'SOFT_SELL', 'HARD_SELL'
    risk_factor: float  # 1x or 2x based on zone
    ma_crossover: bool  # Green line crosses above/below Red line
    rejection_pattern: bool  # Price rejecting zone levels


class SuperTDI:
    """Super Traders Dynamic Index indicator implementation."""
    
    def __init__(self, config):
        self.rsi_period = config.rsi_period
        self.rsi_price_line = config.rsi_price_line
        self.rsi_signal_line = config.rsi_signal_line
        self.rsi_timeframe = config.rsi_timeframe
        self.band_length = config.band_length
        self.band_mult = config.band_mult
        self.momentum_lookback = config.momentum_lookback
        
        # Enhanced zone levels
        self.hard_buy_zone = config.hard_buy_zone
        self.soft_buy_zone = config.soft_buy_zone
        self.no_trade_zone_lower = config.no_trade_zone_lower
        self.no_trade_zone_upper = config.no_trade_zone_upper
        self.soft_sell_zone = config.soft_sell_zone
        self.hard_sell_zone = config.hard_sell_zone
        
        # Legacy support
        self.oversold_level = config.oversold_level
        self.overbought_level = config.overbought_level
    
    def calculate_rsi(self, prices: pd.Series, period: int) -> pd.Series:
        """Calculate RSI (Relative Strength Index)."""
        delta = prices.diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        avg_gain = gain.rolling(window=period, min_periods=1).mean()
        avg_loss = loss.rolling(window=period, min_periods=1).mean()
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calculate_sma(self, data: pd.Series, period: int) -> pd.Series:
        """Calculate Simple Moving Average."""
        return data.rolling(window=period, min_periods=1).mean()
    
    def calculate_bollinger_bands(self, data: pd.Series, period: int, multiplier: float):
        """Calculate Bollinger Bands for volatility bands."""
        sma = self.calculate_sma(data, period)
        std = data.rolling(window=period, min_periods=1).std()
        
        upper_band = sma + (std * multiplier)
        lower_band = sma - (std * multiplier)
        
        return upper_band, lower_band, sma
    
    def calculate_momentum(self, rsi: pd.Series, lookback: int) -> pd.Series:
        """Calculate momentum based on RSI changes."""
        return rsi.diff(lookback)
    
    def determine_tdi_zone(self, rsi_value: float) -> tuple:
        """Determine TDI zone and risk factor based on RSI value."""
        if rsi_value <= self.hard_buy_zone:
            return 'HARD_BUY', 2.0
        elif rsi_value <= self.soft_buy_zone:
            return 'SOFT_BUY', 1.0
        elif self.no_trade_zone_lower <= rsi_value <= self.no_trade_zone_upper:
            return 'NO_TRADE', 0.0
        elif rsi_value >= self.hard_sell_zone:
            return 'HARD_SELL', 2.0
        elif rsi_value >= self.soft_sell_zone:
            return 'SOFT_SELL', 1.0
        else:
            return 'NO_TRADE', 0.0
    
    def detect_ma_crossover(self, rsi_ma: pd.Series, rsi_signal: pd.Series) -> pd.Series:
        """Detect Green line (price) crossing above/below Red line (signal)."""
        crossovers = pd.Series(index=rsi_ma.index, dtype=bool)
        crossovers.iloc[0] = False
        
        for i in range(1, len(rsi_ma)):
            if pd.isna(rsi_ma.iloc[i]) or pd.isna(rsi_signal.iloc[i]):
                crossovers.iloc[i] = False
                continue
            
            prev_above = rsi_ma.iloc[i-1] > rsi_signal.iloc[i-1]
            curr_above = rsi_ma.iloc[i] > rsi_signal.iloc[i]
            
            # Crossover detected if state changed
            crossovers.iloc[i] = prev_above != curr_above
        
        return crossovers
    
    def detect_zone_rejection(self, rsi: pd.Series, price_data: pd.Series) -> pd.Series:
        """Detect price rejection patterns at zone levels."""
        rejections = pd.Series(index=rsi.index, dtype=bool, default=False)
        
        for i in range(2, len(rsi)):
            current_rsi = rsi.iloc[i]
            prev_rsi = rsi.iloc[i-1]
            prev2_rsi = rsi.iloc[i-2]
            
            # Check for rejection at buy zones
            if (prev2_rsi <= self.soft_buy_zone and 
                prev_rsi <= self.soft_buy_zone and 
                current_rsi > prev_rsi):
                rejections.iloc[i] = True
            
            # Check for rejection at sell zones
            elif (prev2_rsi >= self.soft_sell_zone and 
                  prev_rsi >= self.soft_sell_zone and 
                  current_rsi < prev_rsi):
                rejections.iloc[i] = True
        
        return rejections

    def determine_trend(self, rsi_ma: pd.Series, rsi_signal: pd.Series) -> pd.Series:
        """Determine trend direction based on MA crossovers."""
        trend = pd.Series(index=rsi_ma.index, dtype=str)
        
        # Bullish when price line above signal line
        bullish = rsi_ma > rsi_signal
        bearish = rsi_ma < rsi_signal
        
        trend[bullish] = 'BULLISH'
        trend[bearish] = 'BEARISH'
        trend.fillna('NEUTRAL', inplace=True)
        
        return trend
    
    def calculate_signal_strength(self, rsi: pd.Series, rsi_ma: pd.Series, 
                                 rsi_signal: pd.Series, momentum: pd.Series) -> pd.Series:
        """Calculate signal strength based on multiple factors."""
        strength = pd.Series(index=rsi.index, dtype=float)
        
        # Distance between price line and signal line
        ma_distance = abs(rsi_ma - rsi_signal) / 100
        
        # RSI position relative to extreme levels
        rsi_extreme = np.where(
            rsi < self.oversold_level, (self.oversold_level - rsi) / self.oversold_level,
            np.where(rsi > self.overbought_level, (rsi - self.overbought_level) / (100 - self.overbought_level), 0)
        )
        
        # Momentum strength
        momentum_strength = abs(momentum) / 50  # Normalize momentum
        
        # Combine factors
        strength = (ma_distance + rsi_extreme + momentum_strength) / 3
        strength = np.clip(strength, 0, 1)
        
        return pd.Series(strength, index=rsi.index)
    
    def generate_signals(self, rsi: pd.Series, rsi_ma: pd.Series, rsi_signal: pd.Series,
                        upper_band: pd.Series, lower_band: pd.Series, momentum: pd.Series,
                        trend: pd.Series, strength: pd.Series) -> pd.Series:
        """Generate enhanced buy/sell/hold signals based on TDI zones and crossovers."""
        signals = pd.Series(index=rsi.index, dtype=str)
        signals.fillna('HOLD', inplace=True)
        
        # Detect MA crossovers (Green line crossing Red line)
        crossovers = self.detect_ma_crossover(rsi_ma, rsi_signal)
        
        for i in range(len(rsi)):
            rsi_val = rsi.iloc[i]
            zone, risk_factor = self.determine_tdi_zone(rsi_val)
            
            # Skip no-trade zones
            if zone == 'NO_TRADE':
                signals.iloc[i] = 'HOLD'
                continue
            
            # Buy signal conditions based on README requirements
            if zone in ['HARD_BUY', 'SOFT_BUY']:
                # 1. TDI in buyer zone (below 50 or rejecting 35/25)
                in_buyer_zone = rsi_val < 50 or (zone in ['HARD_BUY', 'SOFT_BUY'])
                
                # 2. Green line crosses above Red line
                ma_bullish_cross = (crossovers.iloc[i] and 
                                  rsi_ma.iloc[i] > rsi_signal.iloc[i])
                
                # 3. Additional confirmation factors
                positive_momentum = momentum.iloc[i] > 0 if i < len(momentum) else False
                strong_signal = strength.iloc[i] > 0.6 if i < len(strength) else False
                
                if in_buyer_zone and (ma_bullish_cross or positive_momentum):
                    if zone == 'HARD_BUY' and strong_signal:
                        signals.iloc[i] = 'STRONG_BUY'
                    else:
                        signals.iloc[i] = 'BUY'
            
            # Sell signal conditions based on README requirements
            elif zone in ['HARD_SELL', 'SOFT_SELL']:
                # 1. TDI in seller zone (above 50 or rejecting 65/75)
                in_seller_zone = rsi_val > 50 or (zone in ['HARD_SELL', 'SOFT_SELL'])
                
                # 2. Green line crosses below Red line
                ma_bearish_cross = (crossovers.iloc[i] and 
                                  rsi_ma.iloc[i] < rsi_signal.iloc[i])
                
                # 3. Additional confirmation factors
                negative_momentum = momentum.iloc[i] < 0 if i < len(momentum) else False
                strong_signal = strength.iloc[i] > 0.6 if i < len(strength) else False
                
                if in_seller_zone and (ma_bearish_cross or negative_momentum):
                    if zone == 'HARD_SELL' and strong_signal:
                        signals.iloc[i] = 'STRONG_SELL'
                    else:
                        signals.iloc[i] = 'SELL'
        
        return signals
    
    def calculate(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Calculate Super TDI indicator and generate signals.
        
        Args:
            data: DataFrame with OHLCV data
            
        Returns:
            Dictionary containing TDI signals and components
        """
        if len(data) < max(self.rsi_period, self.band_length):
            return {
                'signals': pd.Series(dtype=str),
                'rsi': pd.Series(dtype=float),
                'rsi_ma': pd.Series(dtype=float),
                'rsi_signal': pd.Series(dtype=float),
                'upper_band': pd.Series(dtype=float),
                'lower_band': pd.Series(dtype=float),
                'momentum': pd.Series(dtype=float),
                'trend': pd.Series(dtype=str),
                'strength': pd.Series(dtype=float),
                'latest_signal': None
            }
        
        # Calculate RSI
        rsi = self.calculate_rsi(data['close'], self.rsi_period)
        
        # Calculate RSI moving averages (price line and signal line)
        rsi_ma = self.calculate_sma(rsi, self.rsi_price_line)  # Price line
        rsi_signal = self.calculate_sma(rsi_ma, self.rsi_signal_line)  # Signal line
        
        # Calculate volatility bands based on RSI
        upper_band, lower_band, middle_band = self.calculate_bollinger_bands(
            rsi, self.band_length, self.band_mult
        )
        
        # Calculate momentum
        momentum = self.calculate_momentum(rsi, self.momentum_lookback)
        
        # Determine trend direction
        trend = self.determine_trend(rsi_ma, rsi_signal)
        
        # Calculate signal strength
        strength = self.calculate_signal_strength(rsi, rsi_ma, rsi_signal, momentum)
        
        # Generate trading signals
        signals = self.generate_signals(
            rsi, rsi_ma, rsi_signal, upper_band, lower_band, 
            momentum, trend, strength
        )
        
        # Get latest signal data with enhanced zone information
        latest_signal = None
        if len(signals) > 0:
            latest_idx = signals.index[-1]
            latest_rsi = rsi.iloc[-1] if len(rsi) > 0 else 50.0
            zone, risk_factor = self.determine_tdi_zone(latest_rsi)
            
            # Detect crossovers for latest signal
            crossovers = self.detect_ma_crossover(rsi_ma, rsi_signal)
            ma_crossover = crossovers.iloc[-1] if len(crossovers) > 0 else False
            
            # Detect rejection patterns
            rejections = self.detect_zone_rejection(rsi, data['close'])
            rejection_pattern = rejections.iloc[-1] if len(rejections) > 0 else False
            
            latest_signal = TDISignal(
                signal=signals.iloc[-1],
                strength=strength.iloc[-1] if len(strength) > 0 else 0.0,
                rsi_value=latest_rsi,
                rsi_ma=rsi_ma.iloc[-1] if len(rsi_ma) > 0 else 50.0,
                rsi_signal=rsi_signal.iloc[-1] if len(rsi_signal) > 0 else 50.0,
                volatility_band_upper=upper_band.iloc[-1] if len(upper_band) > 0 else 70.0,
                volatility_band_lower=lower_band.iloc[-1] if len(lower_band) > 0 else 30.0,
                momentum=momentum.iloc[-1] if len(momentum) > 0 else 0.0,
                trend_direction=trend.iloc[-1] if len(trend) > 0 else 'NEUTRAL',
                confidence=min(strength.iloc[-1] * 100, 100) if len(strength) > 0 else 0.0,
                zone=zone,
                risk_factor=risk_factor,
                ma_crossover=ma_crossover,
                rejection_pattern=rejection_pattern
            )
        
        return {
            'signals': signals,
            'rsi': rsi,
            'rsi_ma': rsi_ma,
            'rsi_signal': rsi_signal,
            'upper_band': upper_band,
            'lower_band': lower_band,
            'momentum': momentum,
            'trend': trend,
            'strength': strength,
            'latest_signal': latest_signal
        }
    
    def get_signal_description(self, signal: str) -> str:
        """Get human-readable description of signal."""
        descriptions = {
            'STRONG_BUY': 'Strong bullish signal with high confidence',
            'BUY': 'Bullish signal indicating potential upward movement',
            'HOLD': 'Neutral signal, maintain current position',
            'SELL': 'Bearish signal indicating potential downward movement',
            'STRONG_SELL': 'Strong bearish signal with high confidence'
        }
        return descriptions.get(signal, 'Unknown signal')
