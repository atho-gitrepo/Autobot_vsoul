"""
Backtesting Package
Contains modules for strategy backtesting and performance evaluation.
"""

from .backtester import Backtester, BacktestResults, Trade

__all__ = ['Backtester', 'BacktestResults', 'Trade']
