"""
Backtesting Engine
Comprehensive backtesting system for evaluating trading strategies.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
import logging
import json

from src.indicators.super_tdi import SuperTDI
from src.indicators.super_bollinger import SuperBollinger
from src.strategy.consolidated_strategy import ConsolidatedStrategy
from src.data.data_collector import DataCollector


@dataclass
class Trade:
    """Individual trade record."""
    entry_time: datetime
    exit_time: Optional[datetime] = None
    symbol: str = ""
    side: str = ""  # 'BUY' or 'SELL'
    entry_price: float = 0.0
    exit_price: Optional[float] = None
    quantity: float = 0.0
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    commission: float = 0.0
    pnl: Optional[float] = None
    pnl_pct: Optional[float] = None
    status: str = "OPEN"  # 'OPEN', 'CLOSED', 'STOPPED'
    signal_confidence: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class BacktestResults:
    """Comprehensive backtest results."""
    # Basic metrics
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    win_rate: float = 0.0
    
    # P&L metrics
    total_pnl: float = 0.0
    total_pnl_pct: float = 0.0
    avg_win: float = 0.0
    avg_loss: float = 0.0
    largest_win: float = 0.0
    largest_loss: float = 0.0
    profit_factor: float = 0.0
    
    # Risk metrics
    max_drawdown: float = 0.0
    max_drawdown_pct: float = 0.0
    sharpe_ratio: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    
    # Portfolio metrics
    initial_capital: float = 0.0
    final_capital: float = 0.0
    peak_capital: float = 0.0
    
    # Time metrics
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    total_days: int = 0
    
    # Trade details
    trades: List[Trade] = field(default_factory=list)
    equity_curve: pd.Series = field(default_factory=pd.Series)
    daily_returns: pd.Series = field(default_factory=pd.Series)


class Backtester:
    """
    Comprehensive backtesting engine for trading strategies.
    """
    
    def __init__(self, strategy: ConsolidatedStrategy, settings):
        self.strategy = strategy
        self.settings = settings
        self.logger = logging.getLogger(__name__)
        
        # Backtest configuration
        self.initial_capital = settings.get('backtest.initial_capital', 10000)
        self.commission = settings.get('backtest.commission', 0.001)  # 0.1%
        self.slippage = settings.get('backtest.slippage', 0.0005)  # 0.05%
        
        # Position sizing
        self.position_size_pct = strategy.position_size_pct
        self.max_positions = strategy.config.get('max_positions', 3)
        
        # Risk management
        self.max_risk_per_trade = 0.02  # 2% max risk per trade
        self.max_portfolio_risk = 0.06  # 6% max portfolio risk
        
        # State tracking
        self.current_capital = self.initial_capital
        self.peak_capital = self.initial_capital
        self.open_trades: List[Trade] = []
        self.closed_trades: List[Trade] = []
        self.equity_history: List[Tuple[datetime, float]] = []
        
    def reset_state(self):
        """Reset backtester state for new run."""
        self.current_capital = self.initial_capital
        self.peak_capital = self.initial_capital
        self.open_trades = []
        self.closed_trades = []
        self.equity_history = []
    
    def calculate_position_size(self, price: float, stop_loss: Optional[float] = None) -> float:
        """Calculate position size based on risk management rules."""
        # Base position size as percentage of capital
        base_size = self.current_capital * self.position_size_pct
        
        if stop_loss and price > 0:
            # Risk-based position sizing
            risk_per_share = abs(price - stop_loss)
            max_risk_amount = self.current_capital * self.max_risk_per_trade
            
            if risk_per_share > 0:
                risk_based_size = max_risk_amount / risk_per_share
                position_size = min(base_size, risk_based_size)
            else:
                position_size = base_size
        else:
            position_size = base_size
        
        # Convert to number of shares/units
        quantity = position_size / price if price > 0 else 0
        
        return max(0, quantity)
    
    def apply_slippage_and_commission(self, price: float, side: str, quantity: float) -> Tuple[float, float]:
        """Apply slippage and commission to trade execution."""
        # Apply slippage
        if side == 'BUY':
            execution_price = price * (1 + self.slippage)
        else:  # SELL
            execution_price = price * (1 - self.slippage)
        
        # Calculate commission
        trade_value = execution_price * quantity
        commission = trade_value * self.commission
        
        return execution_price, commission
    
    def can_open_position(self, required_capital: float) -> bool:
        """Check if we can open a new position."""
        # Check capital availability
        if required_capital > self.current_capital * 0.95:  # Keep 5% buffer
            return False
        
        # Check maximum positions limit
        if len(self.open_trades) >= self.max_positions:
            return False
        
        # Check portfolio risk
        total_portfolio_risk = sum(
            abs(trade.entry_price - (trade.stop_loss or trade.entry_price)) * trade.quantity
            for trade in self.open_trades
        )
        
        if total_portfolio_risk > self.current_capital * self.max_portfolio_risk:
            return False
        
        return True
    
    def open_trade(self, signal: Dict[str, Any], timestamp: datetime, price: float) -> Optional[Trade]:
        """Open a new trade based on signal."""
        try:
            side = signal['action']
            stop_loss = signal.get('stop_loss')
            take_profit = signal.get('take_profit')
            confidence = signal.get('confidence', 0)
            
            # Calculate position size
            quantity = self.calculate_position_size(price, stop_loss)
            
            if quantity <= 0:
                self.logger.warning(f"Invalid quantity calculated: {quantity}")
                return None
            
            # Calculate required capital
            required_capital = price * quantity
            
            # Check if we can open the position
            if not self.can_open_position(required_capital):
                self.logger.debug(f"Cannot open position: insufficient capital or risk limits")
                return None
            
            # Apply slippage and commission
            execution_price, commission = self.apply_slippage_and_commission(price, side, quantity)
            
            # Create trade
            trade = Trade(
                entry_time=timestamp,
                symbol=signal.get('symbol', 'UNKNOWN'),
                side=side,
                entry_price=execution_price,
                quantity=quantity,
                stop_loss=stop_loss,
                take_profit=take_profit,
                commission=commission,
                signal_confidence=confidence,
                metadata={
                    'tdi_signal': signal.get('tdi_signal'),
                    'bollinger_signal': signal.get('bollinger_signal'),
                    'strategy_name': signal.get('strategy_name')
                }
            )
            
            # Update capital
            self.current_capital -= required_capital + commission
            
            # Add to open trades
            self.open_trades.append(trade)
            
            self.logger.debug(f"Opened {side} trade: {quantity:.4f} units at {execution_price:.4f}")
            
            return trade
            
        except Exception as e:
            self.logger.error(f"Error opening trade: {e}")
            return None
    
    def close_trade(self, trade: Trade, timestamp: datetime, price: float, reason: str = "SIGNAL") -> Trade:
        """Close an existing trade."""
        try:
            # Apply slippage and commission for exit
            opposite_side = 'SELL' if trade.side == 'BUY' else 'BUY'
            execution_price, commission = self.apply_slippage_and_commission(price, opposite_side, trade.quantity)
            
            # Update trade
            trade.exit_time = timestamp
            trade.exit_price = execution_price
            trade.commission += commission
            trade.status = reason
            
            # Calculate P&L
            if trade.side == 'BUY':
                trade.pnl = (execution_price - trade.entry_price) * trade.quantity - trade.commission
            else:  # SELL
                trade.pnl = (trade.entry_price - execution_price) * trade.quantity - trade.commission
            
            trade.pnl_pct = (trade.pnl / (trade.entry_price * trade.quantity)) * 100
            
            # Update capital
            trade_value = execution_price * trade.quantity
            self.current_capital += trade_value - commission
            
            # Update peak capital
            self.peak_capital = max(self.peak_capital, self.current_capital)
            
            # Move to closed trades
            if trade in self.open_trades:
                self.open_trades.remove(trade)
            self.closed_trades.append(trade)
            
            self.logger.debug(f"Closed trade: P&L = {trade.pnl:.2f} ({trade.pnl_pct:.2f}%)")
            
            return trade
            
        except Exception as e:
            self.logger.error(f"Error closing trade: {e}")
            return trade
    
    def check_stop_loss_take_profit(self, timestamp: datetime, data: pd.Series):
        """Check and execute stop loss / take profit orders."""
        trades_to_close = []
        
        for trade in self.open_trades:
            current_price = data['close']
            
            if trade.side == 'BUY':
                # Check stop loss
                if trade.stop_loss and current_price <= trade.stop_loss:
                    trades_to_close.append((trade, trade.stop_loss, "STOPPED"))
                # Check take profit
                elif trade.take_profit and current_price >= trade.take_profit:
                    trades_to_close.append((trade, trade.take_profit, "PROFIT"))
                    
            else:  # SELL
                # Check stop loss
                if trade.stop_loss and current_price >= trade.stop_loss:
                    trades_to_close.append((trade, trade.stop_loss, "STOPPED"))
                # Check take profit
                elif trade.take_profit and current_price <= trade.take_profit:
                    trades_to_close.append((trade, trade.take_profit, "PROFIT"))
        
        # Close trades that hit stop/target
        for trade, exit_price, reason in trades_to_close:
            self.close_trade(trade, timestamp, exit_price, reason)
    
    def process_signal(self, signal: Dict[str, Any], timestamp: datetime, data: pd.Series):
        """Process a trading signal."""
        current_price = data['close']
        action = signal['action']
        
        if action in ['BUY', 'SELL']:
            # Check if we should close existing opposite positions
            opposite_action = 'SELL' if action == 'BUY' else 'BUY'
            trades_to_close = [trade for trade in self.open_trades if trade.side == opposite_action]
            
            for trade in trades_to_close:
                self.close_trade(trade, timestamp, current_price, "SIGNAL_REVERSAL")
            
            # Open new position
            self.open_trade(signal, timestamp, current_price)
    
    def run_backtest(self, data_dict: Dict[str, pd.DataFrame], 
                    start_date: Optional[datetime] = None,
                    end_date: Optional[datetime] = None) -> BacktestResults:
        """
        Run comprehensive backtest on historical data.
        
        Args:
            data_dict: Dictionary mapping symbols to their historical data
            start_date: Start date for backtest
            end_date: End date for backtest
            
        Returns:
            BacktestResults object with comprehensive metrics
        """
        self.logger.info("Starting backtest...")
        
        # Reset state
        self.reset_state()
        
        # Get common time index across all symbols
        all_indices = [df.index for df in data_dict.values() if df is not None and len(df) > 0]
        if not all_indices:
            raise ValueError("No valid data provided for backtesting")
        
        # Find common time range
        common_start = max(idx.min() for idx in all_indices)
        common_end = min(idx.max() for idx in all_indices)
        
        if start_date:
            common_start = max(common_start, start_date)
        if end_date:
            common_end = min(common_end, end_date)
        
        self.logger.info(f"Backtest period: {common_start} to {common_end}")
        
        # Initialize indicators for each symbol
        indicators = {}
        for symbol in data_dict.keys():
            if data_dict[symbol] is not None:
                indicators[symbol] = {
                    'tdi': SuperTDI(self.strategy.tdi.config if hasattr(self.strategy.tdi, 'config') else self.settings.tdi_config),
                    'bollinger': SuperBollinger(self.strategy.bollinger.config if hasattr(self.strategy.bollinger, 'config') else self.settings.bollinger_config)
                }
        
        # Main backtest loop
        processed_count = 0
        total_signals = 0
        
        try:
            # Process each time step
            for symbol, df in data_dict.items():
                if df is None or len(df) == 0:
                    continue
                
                # Filter data to backtest period
                symbol_data = df[(df.index >= common_start) & (df.index <= common_end)]
                
                if len(symbol_data) < 50:  # Minimum data requirement
                    self.logger.warning(f"Insufficient data for {symbol}: {len(symbol_data)} periods")
                    continue
                
                self.logger.info(f"Processing {symbol} with {len(symbol_data)} data points")
                
                # Calculate indicators for the entire period
                tdi_result = indicators[symbol]['tdi'].calculate(symbol_data)
                bollinger_result = indicators[symbol]['bollinger'].calculate(symbol_data)
                
                # Process each time step for this symbol
                for i in range(len(symbol_data)):
                    timestamp = symbol_data.index[i]
                    current_data = symbol_data.iloc[:i+1]  # Data up to current point
                    
                    # Skip if insufficient data
                    if len(current_data) < self.strategy.config.get('min_data_points', 50):
                        continue
                    
                    # Check stop loss / take profit for existing trades
                    self.check_stop_loss_take_profit(timestamp, symbol_data.iloc[i])
                    
                    # Get current indicator signals
                    if (len(tdi_result.get('signals', pd.Series())) > i and 
                        len(bollinger_result.get('signals', pd.Series())) > i):
                        
                        # Create mock signal objects for current timepoint
                        current_tdi_values = {}
                        current_bollinger_values = {}
                        
                        for key, series in tdi_result.items():
                            if isinstance(series, pd.Series) and len(series) > i:
                                current_tdi_values[key] = series.iloc[i]
                        
                        for key, series in bollinger_result.items():
                            if isinstance(series, pd.Series) and len(series) > i:
                                current_bollinger_values[key] = series.iloc[i]
                        
                        # Generate strategy signal
                        try:
                            signal = self.strategy.generate_signal(current_data, tdi_result, bollinger_result)
                            
                            if signal:
                                signal_dict = {
                                    'action': signal.action,
                                    'confidence': signal.confidence,
                                    'stop_loss': signal.stop_loss,
                                    'take_profit': signal.take_profit,
                                    'tdi_signal': signal.tdi_signal,
                                    'bollinger_signal': signal.bollinger_signal,
                                    'strategy_name': signal.strategy_name,
                                    'symbol': symbol
                                }
                                
                                self.process_signal(signal_dict, timestamp, symbol_data.iloc[i])
                                total_signals += 1
                                
                        except Exception as e:
                            self.logger.error(f"Error generating signal for {symbol} at {timestamp}: {e}")
                    
                    # Record equity curve
                    total_equity = self.current_capital + sum(
                        trade.quantity * symbol_data.iloc[i]['close'] 
                        for trade in self.open_trades
                        if trade.symbol == symbol
                    )
                    self.equity_history.append((timestamp, total_equity))
                    
                    processed_count += 1
                    
                    if processed_count % 1000 == 0:
                        self.logger.debug(f"Processed {processed_count} data points")
        
        except Exception as e:
            self.logger.error(f"Error during backtest execution: {e}")
            raise
        
        # Close any remaining open trades at the end
        if self.open_trades:
            final_timestamp = common_end
            for symbol, df in data_dict.items():
                if df is not None and len(df) > 0:
                    final_data = df[df.index <= common_end]
                    if len(final_data) > 0:
                        final_price = final_data['close'].iloc[-1]
                        trades_to_close = [trade for trade in self.open_trades if trade.symbol == symbol]
                        for trade in trades_to_close:
                            self.close_trade(trade, final_timestamp, final_price, "BACKTEST_END")
        
        # Calculate results
        results = self.calculate_results(common_start, common_end)
        
        self.logger.info(f"Backtest completed: {len(self.closed_trades)} trades, "
                        f"Win rate: {results.win_rate:.1f}%, "
                        f"Total return: {results.total_pnl_pct:.2f}%")
        
        return results
    
    def calculate_results(self, start_date: datetime, end_date: datetime) -> BacktestResults:
        """Calculate comprehensive backtest results."""
        results = BacktestResults()
        
        # Basic trade statistics
        results.total_trades = len(self.closed_trades)
        results.initial_capital = self.initial_capital
        results.final_capital = self.current_capital
        results.peak_capital = self.peak_capital
        results.start_date = start_date
        results.end_date = end_date
        results.total_days = (end_date - start_date).days
        results.trades = self.closed_trades.copy()
        
        if results.total_trades == 0:
            return results
        
        # Separate winning and losing trades
        winning_trades = [t for t in self.closed_trades if t.pnl and t.pnl > 0]
        losing_trades = [t for t in self.closed_trades if t.pnl and t.pnl <= 0]
        
        results.winning_trades = len(winning_trades)
        results.losing_trades = len(losing_trades)
        results.win_rate = (results.winning_trades / results.total_trades) * 100
        
        # P&L calculations
        total_pnl = sum(t.pnl for t in self.closed_trades if t.pnl)
        results.total_pnl = total_pnl
        results.total_pnl_pct = (total_pnl / self.initial_capital) * 100
        
        if winning_trades:
            results.avg_win = sum(t.pnl for t in winning_trades) / len(winning_trades)
            results.largest_win = max(t.pnl for t in winning_trades)
        
        if losing_trades:
            results.avg_loss = sum(t.pnl for t in losing_trades) / len(losing_trades)
            results.largest_loss = min(t.pnl for t in losing_trades)
        
        # Profit factor
        gross_profit = sum(t.pnl for t in winning_trades) if winning_trades else 0
        gross_loss = abs(sum(t.pnl for t in losing_trades)) if losing_trades else 0
        results.profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        # Create equity curve
        if self.equity_history:
            equity_df = pd.DataFrame(self.equity_history, columns=['timestamp', 'equity'])
            equity_df.set_index('timestamp', inplace=True)
            results.equity_curve = equity_df['equity']
            
            # Calculate returns
            results.daily_returns = results.equity_curve.pct_change().dropna()
            
            # Risk metrics
            if len(results.daily_returns) > 0:
                # Maximum drawdown
                rolling_max = results.equity_curve.expanding().max()
                drawdown = results.equity_curve - rolling_max
                results.max_drawdown = drawdown.min()
                results.max_drawdown_pct = (drawdown / rolling_max).min() * 100
                
                # Sharpe ratio (assuming 252 trading days)
                if results.daily_returns.std() > 0:
                    results.sharpe_ratio = (results.daily_returns.mean() / results.daily_returns.std()) * np.sqrt(252)
                
                # Sortino ratio
                negative_returns = results.daily_returns[results.daily_returns < 0]
                if len(negative_returns) > 0 and negative_returns.std() > 0:
                    results.sortino_ratio = (results.daily_returns.mean() / negative_returns.std()) * np.sqrt(252)
                
                # Calmar ratio
                if abs(results.max_drawdown_pct) > 0:
                    annual_return = ((results.final_capital / results.initial_capital) ** (365 / results.total_days) - 1) * 100
                    results.calmar_ratio = annual_return / abs(results.max_drawdown_pct)
        
        return results
    
    def generate_report(self, results: BacktestResults) -> str:
        """Generate a comprehensive backtest report."""
        report = f"""
BACKTEST REPORT
===============

Period: {results.start_date.strftime('%Y-%m-%d')} to {results.end_date.strftime('%Y-%m-%d')}
Duration: {results.total_days} days

PORTFOLIO PERFORMANCE
--------------------
Initial Capital: ${results.initial_capital:,.2f}
Final Capital: ${results.final_capital:,.2f}
Total Return: ${results.total_pnl:,.2f} ({results.total_pnl_pct:.2f}%)
Peak Capital: ${results.peak_capital:,.2f}

TRADE STATISTICS
---------------
Total Trades: {results.total_trades}
Winning Trades: {results.winning_trades}
Losing Trades: {results.losing_trades}
Win Rate: {results.win_rate:.1f}%

P&L ANALYSIS
-----------
Average Win: ${results.avg_win:.2f}
Average Loss: ${results.avg_loss:.2f}
Largest Win: ${results.largest_win:.2f}
Largest Loss: ${results.largest_loss:.2f}
Profit Factor: {results.profit_factor:.2f}

RISK METRICS
-----------
Maximum Drawdown: ${results.max_drawdown:.2f} ({results.max_drawdown_pct:.2f}%)
Sharpe Ratio: {results.sharpe_ratio:.2f}
Sortino Ratio: {results.sortino_ratio:.2f}
Calmar Ratio: {results.calmar_ratio:.2f}
        """
        
        return report.strip()
    
    def save_results(self, results: BacktestResults, filepath: str):
        """Save backtest results to file."""
        try:
            # Prepare data for JSON serialization
            results_dict = {
                'summary': {
                    'total_trades': results.total_trades,
                    'winning_trades': results.winning_trades,
                    'losing_trades': results.losing_trades,
                    'win_rate': results.win_rate,
                    'total_pnl': results.total_pnl,
                    'total_pnl_pct': results.total_pnl_pct,
                    'max_drawdown': results.max_drawdown,
                    'max_drawdown_pct': results.max_drawdown_pct,
                    'sharpe_ratio': results.sharpe_ratio,
                    'profit_factor': results.profit_factor,
                    'initial_capital': results.initial_capital,
                    'final_capital': results.final_capital
                },
                'trades': [
                    {
                        'entry_time': trade.entry_time.isoformat(),
                        'exit_time': trade.exit_time.isoformat() if trade.exit_time else None,
                        'symbol': trade.symbol,
                        'side': trade.side,
                        'entry_price': trade.entry_price,
                        'exit_price': trade.exit_price,
                        'quantity': trade.quantity,
                        'pnl': trade.pnl,
                        'pnl_pct': trade.pnl_pct,
                        'status': trade.status,
                        'signal_confidence': trade.signal_confidence
                    }
                    for trade in results.trades
                ],
                'equity_curve': results.equity_curve.to_dict() if not results.equity_curve.empty else {}
            }
            
            with open(filepath, 'w') as f:
                json.dump(results_dict, f, indent=2, default=str)
            
            self.logger.info(f"Backtest results saved to {filepath}")
            
        except Exception as e:
            self.logger.error(f"Error saving backtest results: {e}")
