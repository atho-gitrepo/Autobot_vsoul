"""
Telegram Notification Bot
Handles sending trading signals and alerts via Telegram.
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
import aiohttp
import json


class TelegramNotifier:
    """Telegram bot for sending trading notifications."""
    
    def __init__(self, settings):
        self.settings = settings
        self.logger = logging.getLogger(__name__)
        
        # Telegram configuration
        self.bot_token = settings.telegram_token
        self.chat_id = settings.telegram_chat_id
        self.parse_mode = settings.get('telegram.parse_mode', 'Markdown')
        
        # API configuration
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        self.session = None
        
        # Rate limiting
        self.last_message_time = {}
        self.min_interval = 5  # Minimum seconds between messages
        
        # Message queue for handling bursts
        self.message_queue = asyncio.Queue()
        self.queue_processor_task = None
        
    async def initialize(self):
        """Initialize Telegram bot and start message processor."""
        try:
            if not self.bot_token or not self.chat_id:
                raise ValueError("Telegram bot token and chat ID must be provided")
            
            # Create HTTP session
            timeout = aiohttp.ClientTimeout(total=30)
            self.session = aiohttp.ClientSession(timeout=timeout)
            
            # Test bot connection
            await self._test_connection()
            
            # Start message queue processor
            self.queue_processor_task = asyncio.create_task(self._process_message_queue())
            
            self.logger.info("Telegram bot initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize Telegram bot: {e}")
            raise
    
    async def shutdown(self):
        """Shutdown Telegram bot and cleanup resources."""
        try:
            # Stop queue processor
            if self.queue_processor_task:
                self.queue_processor_task.cancel()
                try:
                    await self.queue_processor_task
                except asyncio.CancelledError:
                    pass
            
            # Close HTTP session
            if self.session:
                await self.session.close()
                self.session = None
            
            self.logger.info("Telegram bot shutdown completed")
            
        except Exception as e:
            self.logger.error(f"Error during Telegram bot shutdown: {e}")
    
    async def _test_connection(self):
        """Test Telegram bot connection."""
        try:
            url = f"{self.base_url}/getMe"
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get('ok'):
                        bot_info = data.get('result', {})
                        self.logger.info(f"Connected to Telegram bot: {bot_info.get('username', 'Unknown')}")
                    else:
                        raise Exception(f"Telegram API error: {data.get('description')}")
                else:
                    raise Exception(f"HTTP error: {response.status}")
                    
        except Exception as e:
            self.logger.error(f"Telegram connection test failed: {e}")
            raise
    
    async def _send_message_direct(self, message: str, parse_mode: Optional[str] = None) -> bool:
        """Send message directly to Telegram API."""
        try:
            if not self.session:
                self.logger.error("Telegram session not initialized")
                return False
            
            url = f"{self.base_url}/sendMessage"
            payload = {
                'chat_id': self.chat_id,
                'text': message,
                'parse_mode': parse_mode or self.parse_mode
            }
            
            async with self.session.post(url, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get('ok'):
                        return True
                    else:
                        self.logger.error(f"Telegram API error: {data.get('description')}")
                        return False
                else:
                    self.logger.error(f"HTTP error sending message: {response.status}")
                    return False
                    
        except Exception as e:
            self.logger.error(f"Error sending Telegram message: {e}")
            return False
    
    async def _process_message_queue(self):
        """Process message queue to handle rate limiting."""
        while True:
            try:
                # Get message from queue (wait indefinitely)
                message_data = await self.message_queue.get()
                
                if message_data is None:  # Shutdown signal
                    break
                
                message, parse_mode = message_data
                
                # Check rate limiting
                now = datetime.now()
                last_time = self.last_message_time.get(self.chat_id, datetime.min)
                time_since_last = (now - last_time).total_seconds()
                
                if time_since_last < self.min_interval:
                    await asyncio.sleep(self.min_interval - time_since_last)
                
                # Send message
                success = await self._send_message_direct(message, parse_mode)
                
                if success:
                    self.last_message_time[self.chat_id] = datetime.now()
                    self.logger.debug("Message sent successfully via queue")
                else:
                    self.logger.error("Failed to send queued message")
                
                # Mark task as done
                self.message_queue.task_done()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in message queue processor: {e}")
                await asyncio.sleep(1)  # Brief pause before retrying
    
    async def send_message(self, message: str, parse_mode: Optional[str] = None, priority: bool = False) -> bool:
        """
        Send message via Telegram.
        
        Args:
            message: Message text to send
            parse_mode: Parse mode (Markdown, HTML, or None)
            priority: If True, send immediately; if False, queue the message
            
        Returns:
            True if message was sent/queued successfully
        """
        try:
            if not message.strip():
                return False
            
            # Truncate very long messages
            if len(message) > 4000:
                message = message[:3950] + "\n\n... (message truncated)"
            
            if priority:
                # Send immediately for high-priority messages
                return await self._send_message_direct(message, parse_mode)
            else:
                # Queue for normal messages
                await self.message_queue.put((message, parse_mode))
                return True
                
        except Exception as e:
            self.logger.error(f"Error queueing Telegram message: {e}")
            return False
    
    async def send_signal_notification(self, symbol: str, signal: Dict[str, Any]) -> bool:
        """Send enhanced trading signal notification with zone and risk information."""
        try:
            action = signal.get('action', 'UNKNOWN')
            confidence = signal.get('confidence', 0)
            price = signal.get('price', 0)
            timestamp = signal.get('timestamp', datetime.now())
            stop_loss = signal.get('stop_loss', None)
            take_profit = signal.get('take_profit', None)
            
            # Get TDI and Bollinger information
            tdi_signal = signal.get('tdi_signal', '')
            bollinger_signal = signal.get('bollinger_signal', '')
            tdi_zone = signal.get('tdi_zone', 'UNKNOWN')
            risk_factor = signal.get('risk_factor', 1.0)
            tdi_value = signal.get('tdi_value', 0)
            
            # Choose emoji based on action
            emoji_map = {
                'BUY': '🚀',
                'SELL': '📉',
                'STRONG_BUY': '🚀',
                'STRONG_SELL': '📉',
                'BREAKOUT_BUY': '⚡',
                'BREAKOUT_SELL': '💥',
                'HOLD': '⏸️'
            }
            
            emoji = emoji_map.get(action, '🔵')
            
            # Format risk factor display
            risk_factor_text = f"{risk_factor:.0f}x"
            if risk_factor >= 2.0:
                zone_description = f"Hard {action.split('_')[-1].title()} Zone"
            else:
                zone_description = f"Soft {action.split('_')[-1].title()} Zone"
            
            # Format timeframe (from config)
            timeframe = "5m"  # This should come from settings
            
            # Format message to match README example
            message = f"""
{emoji} **{action} Signal** {emoji}

**Symbol:** {symbol}
**Timeframe:** {timeframe}
**Entry Price:** {price:.2f}"""
            
            # Add stop loss and take profit if available
            if stop_loss:
                message += f"\n**Stop Loss:** {stop_loss:.2f}"
            if take_profit:
                message += f"\n**Take Profit:** {take_profit:.2f}"
            
            message += f"""
**Risk Factor:** {risk_factor_text} ({zone_description})
**TDI Value:** {tdi_value:.2f}

**Conditions Met:**"""
            
            # Add condition details based on zone and signals
            if 'BUY' in action:
                if 'HARD' in tdi_zone:
                    message += f"\n- TDI in Hard Buy Zone (below 25)"
                elif 'SOFT' in tdi_zone:
                    message += f"\n- TDI in Soft Buy Zone (below 35)"
                
                if 'rejection' in signal.get('conditions', []):
                    message += f"\n- Price rejected lower Bollinger Band"
                if 'crossover' in signal.get('conditions', []):
                    message += f"\n- MA crossover confirmed"
                if 'volume' in signal.get('conditions', []):
                    message += f"\n- Volume increasing on reversal"
                    
            elif 'SELL' in action:
                if 'HARD' in tdi_zone:
                    message += f"\n- TDI in Hard Sell Zone (above 75)"
                elif 'SOFT' in tdi_zone:
                    message += f"\n- TDI in Soft Sell Zone (above 65)"
                
                if 'rejection' in signal.get('conditions', []):
                    message += f"\n- Price rejected upper Bollinger Band"
                if 'crossover' in signal.get('conditions', []):
                    message += f"\n- MA crossover confirmed"
                if 'volume' in signal.get('conditions', []):
                    message += f"\n- Volume increasing on reversal"
            
            # Add footer information
            message += f"""

**Confidence:** {confidence:.1f}%
**Strategy:** {signal.get('strategy_name', 'Consolidated Trend Strategy')}
**Time:** {timestamp.strftime('%H:%M:%S')}
            """
            
            return await self.send_message(message.strip())
            
        except Exception as e:
            self.logger.error(f"Error sending signal notification: {e}")
            return False
    
    async def send_error_notification(self, error_type: str, error_message: str, context: Optional[Dict] = None) -> bool:
        """Send error notification."""
        try:
            message = f"""
❌ **ERROR ALERT**
🔍 Type: `{error_type}`
📝 Message: `{error_message}`
⏰ Time: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`
            """
            
            if context:
                message += f"\n📋 Context: `{json.dumps(context, default=str)}`"
            
            return await self.send_message(message.strip(), priority=True)
            
        except Exception as e:
            self.logger.error(f"Error sending error notification: {e}")
            return False
    
    async def send_daily_summary(self, summary: Dict[str, Any]) -> bool:
        """Send daily trading summary."""
        try:
            date = summary.get('date', datetime.now().strftime('%Y-%m-%d'))
            
            message = f"""
📊 **DAILY SUMMARY - {date}**

**Signal Statistics:**
• Total Signals: `{summary.get('total_signals', 0)}`
• Buy Signals: `{summary.get('buy_signals', 0)}`
• Sell Signals: `{summary.get('sell_signals', 0)}`
• Avg Confidence: `{summary.get('avg_confidence', 0):.1f}%`

**Active Symbols:**
{chr(10).join(f'• {symbol}' for symbol in summary.get('symbols', []))}

**Performance:**
• Strategy Accuracy: `{summary.get('accuracy', 0):.1f}%`
• Total Trades: `{summary.get('total_trades', 0)}`

🤖 Bot Status: `Running`
            """
            
            return await self.send_message(message.strip())
            
        except Exception as e:
            self.logger.error(f"Error sending daily summary: {e}")
            return False
    
    async def send_system_status(self, status: Dict[str, Any]) -> bool:
        """Send system status update."""
        try:
            uptime = status.get('uptime', 'Unknown')
            memory_usage = status.get('memory_usage', 0)
            cpu_usage = status.get('cpu_usage', 0)
            
            status_emoji = "🟢" if status.get('healthy', True) else "🔴"
            
            message = f"""
{status_emoji} **SYSTEM STATUS**

**Bot Health:** `{'Healthy' if status.get('healthy', True) else 'Issues Detected'}`
**Uptime:** `{uptime}`
**Memory Usage:** `{memory_usage:.1f}%`
**CPU Usage:** `{cpu_usage:.1f}%`

**Data Sources:**
• Market Data: `{'Connected' if status.get('data_connected', True) else 'Disconnected'}`
• Database: `{'Connected' if status.get('db_connected', True) else 'Disconnected'}`

**Last Update:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`
            """
            
            return await self.send_message(message.strip())
            
        except Exception as e:
            self.logger.error(f"Error sending system status: {e}")
            return False
    
    async def send_custom_message(self, title: str, content: Dict[str, Any], emoji: str = "ℹ️") -> bool:
        """Send custom formatted message."""
        try:
            message = f"{emoji} **{title.upper()}**\n\n"
            
            for key, value in content.items():
                if isinstance(value, dict):
                    message += f"**{key.replace('_', ' ').title()}:**\n"
                    for sub_key, sub_value in value.items():
                        message += f"• {sub_key.replace('_', ' ').title()}: `{sub_value}`\n"
                    message += "\n"
                else:
                    message += f"**{key.replace('_', ' ').title()}:** `{value}`\n"
            
            message += f"\n⏰ Time: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`"
            
            return await self.send_message(message.strip())
            
        except Exception as e:
            self.logger.error(f"Error sending custom message: {e}")
            return False
    
    def format_price(self, price: float, decimals: int = 4) -> str:
        """Format price for display."""
        return f"${price:.{decimals}f}"
    
    def format_percentage(self, value: float, decimals: int = 2) -> str:
        """Format percentage for display."""
        return f"{value:.{decimals}f}%"
    
    async def test_notification(self) -> bool:
        """Send test notification to verify bot is working."""
        try:
            test_message = f"""
🧪 **TEST NOTIFICATION**

This is a test message from the Trading Bot.

✅ Telegram integration is working correctly!
⏰ Test Time: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`

Bot is ready to send trading signals.
            """
            
            return await self.send_message(test_message.strip(), priority=True)
            
        except Exception as e:
            self.logger.error(f"Error sending test notification: {e}")
            return False
