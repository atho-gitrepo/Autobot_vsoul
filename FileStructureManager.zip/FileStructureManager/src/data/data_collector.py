"""
Data Collection Module
Handles fetching market data from various sources.
"""

import pandas as pd
import numpy as np
import requests
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
import logging


class DataCollector:
    """Collects market data from various sources."""
    
    def __init__(self, settings):
        self.settings = settings
        self.logger = logging.getLogger(__name__)
        self.data_source = settings.data_config.get('source', 'binance')
        self.session = None
        
        # API configurations
        self.api_configs = {
            'binance': {
                'base_url': 'https://api.binance.com/api/v3',
                'klines_endpoint': '/klines',
                'timeout': 30
            }
        }
        
        # Timeframe mappings
        self.timeframe_mapping = {
            '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m',
            '1h': '1h', '2h': '2h', '4h': '4h', '6h': '6h', '8h': '8h', '12h': '12h',
            '1d': '1d', '3d': '3d', '1w': '1w', '1M': '1M'
        }
    
    async def _get_session(self):
        """Get or create aiohttp session."""
        if self.session is None:
            timeout = aiohttp.ClientTimeout(total=30)
            self.session = aiohttp.ClientSession(timeout=timeout)
        return self.session
    
    async def close_session(self):
        """Close aiohttp session."""
        if self.session:
            await self.session.close()
            self.session = None
    
    def _convert_timeframe(self, timeframe: str) -> str:
        """Convert timeframe to API format."""
        return self.timeframe_mapping.get(timeframe, '5m')
    
    def _calculate_start_time(self, periods: int, timeframe: str) -> int:
        """Calculate start time timestamp for given periods."""
        timeframe_minutes = {
            '1m': 1, '3m': 3, '5m': 5, '15m': 15, '30m': 30,
            '1h': 60, '2h': 120, '4h': 240, '6h': 360, '8h': 480, '12h': 720,
            '1d': 1440, '3d': 4320, '1w': 10080, '1M': 43200
        }
        
        minutes = timeframe_minutes.get(timeframe, 5)
        start_time = datetime.now() - timedelta(minutes=minutes * periods)
        return int(start_time.timestamp() * 1000)
    
    async def _fetch_binance_data(self, symbol: str, timeframe: str, periods: int) -> Optional[pd.DataFrame]:
        """Fetch data from Binance API."""
        try:
            config = self.api_configs['binance']
            session = await self._get_session()
            
            # Prepare parameters
            api_timeframe = self._convert_timeframe(timeframe)
            start_time = self._calculate_start_time(periods, timeframe)
            
            params = {
                'symbol': symbol.upper(),
                'interval': api_timeframe,
                'startTime': start_time,
                'limit': periods
            }
            
            url = f"{config['base_url']}{config['klines_endpoint']}"
            
            async with session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._process_binance_data(data)
                else:
                    self.logger.error(f"Binance API error: {response.status}")
                    return None
                    
        except Exception as e:
            self.logger.error(f"Error fetching Binance data: {e}")
            return None
    
    def _process_binance_data(self, raw_data: List[List]) -> pd.DataFrame:
        """Process raw Binance API data into DataFrame."""
        try:
            # Binance klines format:
            # [timestamp, open, high, low, close, volume, close_time, quote_volume, count, taker_buy_volume, taker_buy_quote_volume, ignore]
            
            df = pd.DataFrame(raw_data, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'count', 'taker_buy_volume',
                'taker_buy_quote_volume', 'ignore'
            ])
            
            # Convert timestamp to datetime
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Convert price and volume columns to float
            price_columns = ['open', 'high', 'low', 'close']
            volume_columns = ['volume', 'quote_volume', 'taker_buy_volume', 'taker_buy_quote_volume']
            
            for col in price_columns + volume_columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Keep only OHLCV data
            df = df[['open', 'high', 'low', 'close', 'volume']]
            
            # Remove any rows with NaN values
            df.dropna(inplace=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error processing Binance data: {e}")
            return None
    
    def _generate_sample_data(self, symbol: str, periods: int) -> pd.DataFrame:
        """Generate sample OHLCV data for testing (fallback method)."""
        self.logger.warning(f"Generating sample data for {symbol} - this is for testing only!")
        
        # Create timestamps
        timestamps = pd.date_range(
            end=datetime.now(),
            periods=periods,
            freq='5T'  # 5-minute intervals
        )
        
        # Generate realistic price data using random walk
        np.random.seed(hash(symbol) % (2**32))  # Deterministic but symbol-specific
        
        base_price = 50000 if 'BTC' in symbol else 3000 if 'ETH' in symbol else 1.0
        
        # Generate price movements
        returns = np.random.normal(0, 0.001, periods)  # 0.1% volatility
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        # Create OHLCV data
        data = []
        for i, (timestamp, close) in enumerate(zip(timestamps, prices)):
            # Generate realistic OHLC from close price
            volatility = abs(np.random.normal(0, 0.005))
            high = close * (1 + volatility)
            low = close * (1 - volatility)
            open_price = close + np.random.normal(0, close * 0.002)
            
            # Ensure OHLC logic
            high = max(high, open_price, close)
            low = min(low, open_price, close)
            
            # Generate volume
            volume = abs(np.random.normal(1000, 300))
            
            data.append([open_price, high, low, close, volume])
        
        df = pd.DataFrame(data, columns=['open', 'high', 'low', 'close', 'volume'], index=timestamps)
        return df
    
    async def get_market_data(self, symbol: str, timeframe: str, periods: int) -> Optional[pd.DataFrame]:
        """
        Get market data for a symbol.
        
        Args:
            symbol: Trading symbol (e.g., 'BTCUSDT')
            timeframe: Time interval (e.g., '5m', '1h', '1d')
            periods: Number of periods to fetch
            
        Returns:
            DataFrame with OHLCV data or None if failed
        """
        try:
            self.logger.debug(f"Fetching {periods} periods of {timeframe} data for {symbol}")
            
            if self.data_source == 'binance':
                data = await self._fetch_binance_data(symbol, timeframe, periods)
            else:
                self.logger.warning(f"Unsupported data source: {self.data_source}")
                data = None
            
            # Fallback to sample data if API fails
            if data is None or len(data) == 0:
                self.logger.warning(f"API data fetch failed for {symbol}, using sample data")
                data = self._generate_sample_data(symbol, periods)
            
            if data is not None and len(data) > 0:
                self.logger.info(f"Successfully fetched {len(data)} data points for {symbol}")
                return data
            else:
                self.logger.error(f"Failed to get any data for {symbol}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error in get_market_data for {symbol}: {e}")
            return None
    
    async def get_multiple_symbols_data(self, symbols: List[str], timeframe: str, periods: int) -> Dict[str, pd.DataFrame]:
        """
        Get market data for multiple symbols concurrently.
        
        Args:
            symbols: List of trading symbols
            timeframe: Time interval
            periods: Number of periods to fetch
            
        Returns:
            Dictionary mapping symbols to their data
        """
        tasks = []
        for symbol in symbols:
            task = self.get_market_data(symbol, timeframe, periods)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        data_dict = {}
        for symbol, result in zip(symbols, results):
            if isinstance(result, Exception):
                self.logger.error(f"Error fetching data for {symbol}: {result}")
                data_dict[symbol] = None
            else:
                data_dict[symbol] = result
        
        return data_dict
    
    def validate_data(self, data: pd.DataFrame, symbol: str) -> bool:
        """Validate market data quality."""
        try:
            if data is None or len(data) == 0:
                return False
            
            # Check required columns
            required_columns = ['open', 'high', 'low', 'close', 'volume']
            if not all(col in data.columns for col in required_columns):
                self.logger.error(f"Missing required columns for {symbol}")
                return False
            
            # Check for NaN values
            if data[required_columns].isnull().any().any():
                self.logger.error(f"NaN values found in data for {symbol}")
                return False
            
            # Check OHLC logic
            invalid_ohlc = (
                (data['high'] < data['low']) |
                (data['high'] < data['open']) |
                (data['high'] < data['close']) |
                (data['low'] > data['open']) |
                (data['low'] > data['close'])
            )
            
            if invalid_ohlc.any():
                self.logger.error(f"Invalid OHLC data found for {symbol}")
                return False
            
            # Check for negative values
            if (data[required_columns] < 0).any().any():
                self.logger.error(f"Negative values found in data for {symbol}")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error validating data for {symbol}: {e}")
            return False
    
    async def get_symbol_info(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get symbol information and trading rules."""
        try:
            if self.data_source == 'binance':
                session = await self._get_session()
                url = f"{self.api_configs['binance']['base_url']}/exchangeInfo"
                
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        symbols = data.get('symbols', [])
                        
                        for sym_info in symbols:
                            if sym_info['symbol'] == symbol.upper():
                                return sym_info
                        
                        self.logger.warning(f"Symbol {symbol} not found in exchange info")
                        return None
                    else:
                        self.logger.error(f"Failed to get exchange info: {response.status}")
                        return None
            else:
                return None
                
        except Exception as e:
            self.logger.error(f"Error getting symbol info for {symbol}: {e}")
            return None
    
    async def __aenter__(self):
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close_session()
