"""
Data Storage Module
Handles storage and retrieval of market data and trading signals.
"""

import sqlite3
import pandas as pd
import numpy as np
import asyncio
import aiosqlite
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
import logging
import json
import os


class DataStorage:
    """Handles data storage and retrieval using SQLite database."""
    
    def __init__(self, settings):
        self.settings = settings
        self.logger = logging.getLogger(__name__)
        
        # Database configuration
        db_config = settings.database_config
        self.db_path = db_config.get('path', 'data/trading_bot.db')
        
        # Ensure data directory exists
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        # Connection pool
        self._connection = None
    
    async def initialize(self):
        """Initialize database and create tables."""
        try:
            await self._create_tables()
            self.logger.info("Database initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize database: {e}")
            raise
    
    async def _get_connection(self):
        """Get database connection."""
        if self._connection is None:
            self._connection = await aiosqlite.connect(self.db_path)
            # Enable WAL mode for better concurrency
            await self._connection.execute("PRAGMA journal_mode=WAL")
            await self._connection.execute("PRAGMA synchronous=NORMAL")
        return self._connection
    
    async def close(self):
        """Close database connection."""
        if self._connection:
            await self._connection.close()
            self._connection = None
    
    async def _create_tables(self):
        """Create database tables if they don't exist."""
        connection = await self._get_connection()
        
        # Market data table
        await connection.execute("""
            CREATE TABLE IF NOT EXISTS market_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp DATETIME NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                volume REAL NOT NULL,
                timeframe TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(symbol, timestamp, timeframe)
            )
        """)
        
        # Trading signals table
        await connection.execute("""
            CREATE TABLE IF NOT EXISTS trading_signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp DATETIME NOT NULL,
                action TEXT NOT NULL,
                confidence REAL NOT NULL,
                strength REAL NOT NULL,
                strategy_name TEXT NOT NULL,
                tdi_signal TEXT,
                bollinger_signal TEXT,
                price REAL NOT NULL,
                stop_loss REAL,
                take_profit REAL,
                risk_reward_ratio REAL,
                position_size REAL,
                metadata TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Strategy performance table
        await connection.execute("""
            CREATE TABLE IF NOT EXISTS strategy_performance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                strategy_name TEXT NOT NULL,
                symbol TEXT NOT NULL,
                date DATE NOT NULL,
                total_signals INTEGER DEFAULT 0,
                buy_signals INTEGER DEFAULT 0,
                sell_signals INTEGER DEFAULT 0,
                avg_confidence REAL DEFAULT 0,
                performance_metrics TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(strategy_name, symbol, date)
            )
        """)
        
        # Indicator calculations table
        await connection.execute("""
            CREATE TABLE IF NOT EXISTS indicator_calculations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp DATETIME NOT NULL,
                indicator_name TEXT NOT NULL,
                values TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(symbol, timestamp, indicator_name, timeframe)
            )
        """)
        
        # Create indices for better performance
        indices = [
            "CREATE INDEX IF NOT EXISTS idx_market_data_symbol_timestamp ON market_data(symbol, timestamp)",
            "CREATE INDEX IF NOT EXISTS idx_trading_signals_symbol_timestamp ON trading_signals(symbol, timestamp)",
            "CREATE INDEX IF NOT EXISTS idx_strategy_performance_date ON strategy_performance(date)",
            "CREATE INDEX IF NOT EXISTS idx_indicator_calculations_symbol_timestamp ON indicator_calculations(symbol, timestamp)"
        ]
        
        for index_sql in indices:
            await connection.execute(index_sql)
        
        await connection.commit()
    
    async def store_market_data(self, symbol: str, data: pd.DataFrame, timeframe: str = '5m'):
        """Store market data in database."""
        try:
            connection = await self._get_connection()
            
            # Prepare data for insertion
            records = []
            for timestamp, row in data.iterrows():
                records.append((
                    symbol,
                    timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    float(row['open']),
                    float(row['high']),
                    float(row['low']),
                    float(row['close']),
                    float(row['volume']),
                    timeframe
                ))
            
            # Insert data using INSERT OR REPLACE to handle duplicates
            await connection.executemany("""
                INSERT OR REPLACE INTO market_data 
                (symbol, timestamp, open, high, low, close, volume, timeframe)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, records)
            
            await connection.commit()
            self.logger.debug(f"Stored {len(records)} market data records for {symbol}")
            
        except Exception as e:
            self.logger.error(f"Error storing market data for {symbol}: {e}")
            raise
    
    async def store_signal(self, symbol: str, signal: Dict[str, Any], timestamp: datetime):
        """Store trading signal in database."""
        try:
            connection = await self._get_connection()
            
            # Prepare metadata
            metadata = {
                'filters_applied': signal.get('filters_applied', {}),
                'indicator_details': signal.get('indicator_details', {}),
                'market_conditions': signal.get('market_conditions', {})
            }
            
            await connection.execute("""
                INSERT INTO trading_signals 
                (symbol, timestamp, action, confidence, strength, strategy_name, 
                 tdi_signal, bollinger_signal, price, stop_loss, take_profit, 
                 risk_reward_ratio, position_size, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                symbol,
                timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                signal['action'],
                signal['confidence'],
                signal.get('strength', 0),
                signal.get('strategy_name', 'unknown'),
                signal.get('tdi_signal'),
                signal.get('bollinger_signal'),
                signal['price'] if 'price' in signal else 0,
                signal.get('stop_loss'),
                signal.get('take_profit'),
                signal.get('risk_reward_ratio'),
                signal.get('position_size'),
                json.dumps(metadata)
            ))
            
            await connection.commit()
            self.logger.debug(f"Stored trading signal for {symbol}: {signal['action']}")
            
        except Exception as e:
            self.logger.error(f"Error storing signal for {symbol}: {e}")
            raise
    
    async def store_indicator_values(self, symbol: str, indicator_name: str, 
                                   values: Dict[str, Any], timestamp: datetime, timeframe: str = '5m'):
        """Store indicator calculation results."""
        try:
            connection = await self._get_connection()
            
            # Convert pandas Series to JSON-serializable format
            serializable_values = {}
            for key, value in values.items():
                if isinstance(value, pd.Series):
                    # Store only the latest value for storage efficiency
                    serializable_values[key] = float(value.iloc[-1]) if len(value) > 0 else None
                elif isinstance(value, (np.ndarray, list)):
                    serializable_values[key] = [float(x) for x in value[-10:]]  # Store last 10 values
                else:
                    serializable_values[key] = value
            
            await connection.execute("""
                INSERT OR REPLACE INTO indicator_calculations
                (symbol, timestamp, indicator_name, values, timeframe)
                VALUES (?, ?, ?, ?, ?)
            """, (
                symbol,
                timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                indicator_name,
                json.dumps(serializable_values),
                timeframe
            ))
            
            await connection.commit()
            
        except Exception as e:
            self.logger.error(f"Error storing indicator values for {symbol}: {e}")
    
    async def get_market_data(self, symbol: str, start_date: Optional[datetime] = None, 
                            end_date: Optional[datetime] = None, timeframe: str = '5m',
                            limit: Optional[int] = None) -> Optional[pd.DataFrame]:
        """Retrieve market data from database."""
        try:
            connection = await self._get_connection()
            
            # Build query
            query = """
                SELECT timestamp, open, high, low, close, volume
                FROM market_data
                WHERE symbol = ? AND timeframe = ?
            """
            params = [symbol, timeframe]
            
            if start_date:
                query += " AND timestamp >= ?"
                params.append(start_date.strftime('%Y-%m-%d %H:%M:%S'))
            
            if end_date:
                query += " AND timestamp <= ?"
                params.append(end_date.strftime('%Y-%m-%d %H:%M:%S'))
            
            query += " ORDER BY timestamp"
            
            if limit:
                query += f" LIMIT {limit}"
            
            cursor = await connection.execute(query, params)
            rows = await cursor.fetchall()
            
            if not rows:
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(rows, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)
            
            # Convert columns to numeric
            numeric_columns = ['open', 'high', 'low', 'close', 'volume']
            for col in numeric_columns:
                df[col] = pd.to_numeric(df[col])
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error retrieving market data for {symbol}: {e}")
            return None
    
    async def get_recent_signals(self, symbol: Optional[str] = None, 
                               strategy: Optional[str] = None, 
                               limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent trading signals."""
        try:
            connection = await self._get_connection()
            
            query = """
                SELECT * FROM trading_signals
                WHERE 1=1
            """
            params = []
            
            if symbol:
                query += " AND symbol = ?"
                params.append(symbol)
            
            if strategy:
                query += " AND strategy_name = ?"
                params.append(strategy)
            
            query += f" ORDER BY timestamp DESC LIMIT {limit}"
            
            cursor = await connection.execute(query, params)
            rows = await cursor.fetchall()
            
            # Convert to list of dictionaries
            columns = [description[0] for description in cursor.description]
            signals = [dict(zip(columns, row)) for row in rows]
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Error retrieving recent signals: {e}")
            return []
    
    async def get_strategy_performance(self, strategy_name: str, symbol: Optional[str] = None,
                                     days: int = 30) -> Dict[str, Any]:
        """Get strategy performance metrics."""
        try:
            connection = await self._get_connection()
            
            start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
            
            query = """
                SELECT 
                    COUNT(*) as total_signals,
                    SUM(CASE WHEN action = 'BUY' THEN 1 ELSE 0 END) as buy_signals,
                    SUM(CASE WHEN action = 'SELL' THEN 1 ELSE 0 END) as sell_signals,
                    AVG(confidence) as avg_confidence,
                    AVG(strength) as avg_strength,
                    MIN(timestamp) as first_signal,
                    MAX(timestamp) as last_signal
                FROM trading_signals
                WHERE strategy_name = ? AND DATE(timestamp) >= ?
            """
            params = [strategy_name, start_date]
            
            if symbol:
                query += " AND symbol = ?"
                params.append(symbol)
            
            cursor = await connection.execute(query, params)
            row = await cursor.fetchone()
            
            if row:
                columns = [description[0] for description in cursor.description]
                performance = dict(zip(columns, row))
                
                # Calculate additional metrics
                performance['hold_signals'] = performance['total_signals'] - performance['buy_signals'] - performance['sell_signals']
                performance['signal_rate_per_day'] = performance['total_signals'] / days if days > 0 else 0
                
                return performance
            else:
                return {}
                
        except Exception as e:
            self.logger.error(f"Error retrieving strategy performance: {e}")
            return {}
    
    async def cleanup_old_data(self, days_to_keep: int = 90):
        """Clean up old data to manage database size."""
        try:
            connection = await self._get_connection()
            
            cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).strftime('%Y-%m-%d')
            
            # Clean up old market data
            await connection.execute("""
                DELETE FROM market_data 
                WHERE DATE(timestamp) < ?
            """, (cutoff_date,))
            
            # Clean up old indicator calculations
            await connection.execute("""
                DELETE FROM indicator_calculations 
                WHERE DATE(timestamp) < ?
            """, (cutoff_date,))
            
            # Keep signals longer (important for performance analysis)
            signal_cutoff = (datetime.now() - timedelta(days=days_to_keep * 2)).strftime('%Y-%m-%d')
            await connection.execute("""
                DELETE FROM trading_signals 
                WHERE DATE(timestamp) < ?
            """, (signal_cutoff,))
            
            await connection.commit()
            
            # Vacuum database to reclaim space
            await connection.execute("VACUUM")
            
            self.logger.info(f"Cleaned up data older than {days_to_keep} days")
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old data: {e}")
    
    async def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        try:
            connection = await self._get_connection()
            
            stats = {}
            
            # Count records in each table
            tables = ['market_data', 'trading_signals', 'strategy_performance', 'indicator_calculations']
            
            for table in tables:
                cursor = await connection.execute(f"SELECT COUNT(*) FROM {table}")
                count = await cursor.fetchone()
                stats[f'{table}_count'] = count[0] if count else 0
            
            # Get database file size
            if os.path.exists(self.db_path):
                stats['database_size_mb'] = os.path.getsize(self.db_path) / (1024 * 1024)
            else:
                stats['database_size_mb'] = 0
            
            # Get date range of data
            cursor = await connection.execute("""
                SELECT MIN(timestamp) as earliest, MAX(timestamp) as latest 
                FROM market_data
            """)
            date_range = await cursor.fetchone()
            if date_range:
                stats['data_earliest'] = date_range[0]
                stats['data_latest'] = date_range[1]
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting database stats: {e}")
            return {}
