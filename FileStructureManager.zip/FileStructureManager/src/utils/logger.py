"""
Logging Utilities
Configures structured logging for the trading bot application.
"""

import logging
import logging.handlers
import os
import sys
from datetime import datetime
from typing import Optional, Dict, Any
import json


class JSONFormatter(logging.Formatter):
    """Custom JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        # Add extra fields
        if hasattr(record, '__dict__'):
            for key, value in record.__dict__.items():
                if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 
                              'pathname', 'filename', 'module', 'lineno', 
                              'funcName', 'created', 'msecs', 'relativeCreated',
                              'thread', 'threadName', 'processName', 'process',
                              'exc_info', 'exc_text', 'stack_info']:
                    try:
                        # Only add JSON-serializable values
                        json.dumps(value)
                        log_entry[key] = value
                    except (TypeError, ValueError):
                        log_entry[key] = str(value)
        
        return json.dumps(log_entry, default=str)


class TradingBotLogger:
    """Enhanced logger for trading bot with structured logging capabilities."""
    
    def __init__(self, name: str, level: str = 'INFO'):
        self.name = name
        self.level = level
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            self._setup_handlers()
    
    def _setup_handlers(self):
        """Setup console and file handlers."""
        # Console handler with standard format
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        console_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        
        self.logger.addHandler(console_handler)
    
    def add_file_handler(self, log_file: str, max_bytes: int = 10485760, 
                        backup_count: int = 5, use_json: bool = False):
        """Add rotating file handler."""
        try:
            # Ensure log directory exists
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            # Create rotating file handler
            file_handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=max_bytes,
                backupCount=backup_count
            )
            
            file_handler.setLevel(logging.DEBUG)
            
            # Use JSON formatter for file logs if requested
            if use_json:
                file_handler.setFormatter(JSONFormatter())
            else:
                file_format = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                )
                file_handler.setFormatter(file_format)
            
            self.logger.addHandler(file_handler)
            
        except Exception as e:
            self.logger.error(f"Failed to add file handler: {e}")
    
    def log_trade_signal(self, symbol: str, action: str, price: float, 
                        confidence: float, metadata: Optional[Dict] = None):
        """Log structured trade signal."""
        extra_data = {
            'event_type': 'trade_signal',
            'symbol': symbol,
            'action': action,
            'price': price,
            'confidence': confidence,
            'metadata': metadata or {}
        }
        
        self.logger.info(
            f"Trade signal: {action} {symbol} at ${price:.4f} (confidence: {confidence:.1f}%)",
            extra=extra_data
        )
    
    def log_trade_execution(self, trade_id: str, symbol: str, side: str, 
                          quantity: float, price: float, status: str):
        """Log trade execution."""
        extra_data = {
            'event_type': 'trade_execution',
            'trade_id': trade_id,
            'symbol': symbol,
            'side': side,
            'quantity': quantity,
            'price': price,
            'status': status
        }
        
        self.logger.info(
            f"Trade execution: {side} {quantity:.4f} {symbol} at ${price:.4f} - {status}",
            extra=extra_data
        )
    
    def log_performance_metric(self, metric_name: str, value: float, 
                             symbol: Optional[str] = None, timeframe: Optional[str] = None):
        """Log performance metric."""
        extra_data = {
            'event_type': 'performance_metric',
            'metric_name': metric_name,
            'value': value,
            'symbol': symbol,
            'timeframe': timeframe
        }
        
        self.logger.info(
            f"Performance metric: {metric_name} = {value:.4f}",
            extra=extra_data
        )
    
    def log_system_status(self, component: str, status: str, details: Optional[Dict] = None):
        """Log system status."""
        extra_data = {
            'event_type': 'system_status',
            'component': component,
            'status': status,
            'details': details or {}
        }
        
        level = logging.INFO if status == 'healthy' else logging.WARNING
        self.logger.log(
            level,
            f"System status: {component} - {status}",
            extra=extra_data
        )
    
    def log_error_with_context(self, error: Exception, context: Dict[str, Any]):
        """Log error with additional context."""
        extra_data = {
            'event_type': 'error',
            'error_type': type(error).__name__,
            'error_message': str(error),
            'context': context
        }
        
        self.logger.error(
            f"Error: {type(error).__name__}: {str(error)}",
            extra=extra_data,
            exc_info=True
        )
    
    def log_data_quality_issue(self, symbol: str, issue_type: str, 
                              description: str, data_info: Optional[Dict] = None):
        """Log data quality issues."""
        extra_data = {
            'event_type': 'data_quality',
            'symbol': symbol,
            'issue_type': issue_type,
            'description': description,
            'data_info': data_info or {}
        }
        
        self.logger.warning(
            f"Data quality issue: {symbol} - {issue_type}: {description}",
            extra=extra_data
        )
    
    def log_strategy_event(self, strategy_name: str, event_type: str, 
                          details: Dict[str, Any]):
        """Log strategy-related events."""
        extra_data = {
            'event_type': 'strategy_event',
            'strategy_name': strategy_name,
            'strategy_event_type': event_type,
            'details': details
        }
        
        self.logger.info(
            f"Strategy event: {strategy_name} - {event_type}",
            extra=extra_data
        )
    
    def get_logger(self) -> logging.Logger:
        """Get the underlying logger instance."""
        return self.logger


def setup_logger(name: str, level: str = 'INFO', log_file: Optional[str] = None,
                max_file_size: int = 10485760, backup_count: int = 5,
                use_json_file: bool = False) -> logging.Logger:
    """
    Setup a logger with console and optional file output.
    
    Args:
        name: Logger name
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional log file path
        max_file_size: Maximum file size before rotation (bytes)
        backup_count: Number of backup files to keep
        use_json_file: Whether to use JSON format for file logs
        
    Returns:
        Logger instance
    """
    try:
        trading_logger = TradingBotLogger(name, level)
        
        if log_file:
            trading_logger.add_file_handler(
                log_file, max_file_size, backup_count, use_json_file
            )
        
        return trading_logger.get_logger()
        
    except Exception as e:
        # Fallback to basic logger if setup fails
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, level.upper(), logging.INFO))
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        logger.error(f"Failed to setup enhanced logger: {e}")
        return logger


def get_logger(name: str) -> logging.Logger:
    """Get or create a logger instance."""
    return logging.getLogger(name)


class LogContext:
    """Context manager for adding temporary context to log messages."""
    
    def __init__(self, logger: logging.Logger, **context):
        self.logger = logger
        self.context = context
        self.old_factory = None
    
    def __enter__(self):
        old_factory = logging.getLogRecordFactory()
        
        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            for key, value in self.context.items():
                setattr(record, key, value)
            return record
        
        self.old_factory = old_factory
        logging.setLogRecordFactory(record_factory)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.old_factory:
            logging.setLogRecordFactory(self.old_factory)


def log_function_call(logger: logging.Logger, level: int = logging.DEBUG):
    """Decorator to log function calls."""
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger.log(level, f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
            try:
                result = func(*args, **kwargs)
                logger.log(level, f"{func.__name__} completed successfully")
                return result
            except Exception as e:
                logger.error(f"{func.__name__} failed with error: {e}", exc_info=True)
                raise
        return wrapper
    return decorator


def configure_root_logger(level: str = 'INFO'):
    """Configure the root logger for the application."""
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(formatter)
    
    root_logger.addHandler(console_handler)
    
    # Suppress noisy third-party loggers
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('aiohttp').setLevel(logging.WARNING)
    logging.getLogger('asyncio').setLevel(logging.WARNING)


# Initialize logging on module import
if not logging.getLogger().handlers:
    configure_root_logger()
