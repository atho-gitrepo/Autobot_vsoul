"""
Trading Bot Source Package
Contains all core modules for the algorithmic trading bot.
"""

from .indicators import SuperTDI, SuperBollinger, TDISignal, BollingerSignal
from .strategy import ConsolidatedStrategy, ConsolidatedSignal
from .data import DataCollector, DataStorage
from .notifications import TelegramNotifier
from .backtest import Backtester, BacktestResults, Trade
from .utils import setup_logger, get_logger

__version__ = "1.0.0"
__author__ = "Trading Bot Team"

__all__ = [
    'SuperTDI', 'SuperBollinger', 'TDISignal', 'BollingerSignal',
    'ConsolidatedStrategy', 'ConsolidatedSignal',
    'DataCollector', 'DataStorage',
    'TelegramNotifier',
    'Backtester', 'BacktestResults', 'Trade',
    'setup_logger', 'get_logger'
]
