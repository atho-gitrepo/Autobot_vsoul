"""
Trading Strategy Package
Contains implementations of various trading strategies.
"""

from .consolidated_strategy import ConsolidatedStrategy, ConsolidatedSignal

__all__ = ['ConsolidatedStrategy', 'ConsolidatedSignal']
