"""
Consolidated Trading Strategy
Combines Super TDI and Super Bollinger indicators to generate comprehensive trading signals.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from dataclasses import dataclass

from src.indicators.super_tdi import SuperTDI, TDISignal
from src.indicators.super_bollinger import SuperBollinger, BollingerSignal


@dataclass
class ConsolidatedSignal:
    """Enhanced consolidated strategy signal data structure."""
    action: str  # 'BUY', 'SELL', 'HOLD', 'STRONG_BUY', 'STRONG_SELL'
    confidence: float  # Overall confidence 0-100
    strength: float  # Signal strength 0-1
    strategy_name: str
    tdi_signal: str
    bollinger_signal: str
    price: float
    timestamp: datetime
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    risk_reward_ratio: Optional[float] = None
    position_size: Optional[float] = None
    # Enhanced TDI zone information
    tdi_zone: Optional[str] = None  # 'HARD_BUY', 'SOFT_BUY', etc.
    risk_factor: Optional[float] = None  # 1x or 2x based on zone
    tdi_value: Optional[float] = None
    # Bollinger Band information
    bb_rejection: Optional[bool] = None
    bb_reversal_confirmed: Optional[bool] = None
    # Condition tracking
    conditions: Optional[List[str]] = None


class ConsolidatedStrategy:
    """
    Consolidated trading strategy that combines multiple indicators.
    Implements advanced signal filtering and risk management.
    """
    
    def __init__(self, tdi_indicator: SuperTDI, bollinger_indicator: SuperBollinger, config: Dict[str, Any]):
        self.tdi = tdi_indicator
        self.bollinger = bollinger_indicator
        self.config = config
        
        # Strategy parameters
        self.min_confidence = config.get('confidence_threshold', 0.7)
        self.risk_reward_ratio = config.get('risk_reward_ratio', 2.0)
        self.stop_loss_pct = config.get('stop_loss_pct', 0.02)
        self.take_profit_pct = config.get('take_profit_pct', 0.04)
        self.position_size_pct = config.get('position_size_pct', 0.1)
        
        # Signal history for trend analysis
        self.signal_history: List[ConsolidatedSignal] = []
        self.max_history = 100
    
    def calculate_signal_alignment(self, tdi_signal: TDISignal, bollinger_signal: BollingerSignal) -> Dict[str, Any]:
        """Calculate alignment between TDI and Bollinger signals."""
        # Define signal priorities
        signal_values = {
            'STRONG_BUY': 2,
            'BUY': 1,
            'BREAKOUT_BUY': 1.5,
            'HOLD': 0,
            'SELL': -1,
            'BREAKOUT_SELL': -1.5,
            'STRONG_SELL': -2
        }
        
        tdi_value = signal_values.get(tdi_signal.signal, 0)
        bollinger_value = signal_values.get(bollinger_signal.signal, 0)
        
        # Calculate alignment score
        if tdi_value * bollinger_value > 0:  # Same direction
            alignment_score = min(abs(tdi_value), abs(bollinger_value)) / 2  # Normalized 0-1
            direction = 'BULLISH' if tdi_value > 0 else 'BEARISH'
        elif tdi_value * bollinger_value < 0:  # Opposite directions
            alignment_score = 0.2  # Low confidence for conflicting signals
            direction = 'NEUTRAL'
        else:  # One signal is HOLD
            alignment_score = max(abs(tdi_value), abs(bollinger_value)) / 4  # Reduced confidence
            direction = 'BULLISH' if (tdi_value + bollinger_value) > 0 else 'BEARISH' if (tdi_value + bollinger_value) < 0 else 'NEUTRAL'
        
        return {
            'alignment_score': alignment_score,
            'direction': direction,
            'tdi_value': tdi_value,
            'bollinger_value': bollinger_value,
            'signal_strength': (abs(tdi_value) + abs(bollinger_value)) / 4
        }
    
    def apply_signal_filters(self, data: pd.DataFrame, tdi_result: Dict, bollinger_result: Dict) -> Dict[str, bool]:
        """Apply various signal filters to improve accuracy."""
        filters = {}
        
        # Volume confirmation filter
        if 'volume' in data.columns and len(data) >= 20:
            avg_volume = data['volume'].rolling(window=20).mean().iloc[-1]
            current_volume = data['volume'].iloc[-1]
            filters['volume_confirmation'] = current_volume > (avg_volume * 1.2)
        else:
            filters['volume_confirmation'] = True  # Skip if no volume data
        
        # Trend confirmation filter
        if len(data) >= 50:
            # Use 50-period SMA for trend
            sma_50 = data['close'].rolling(window=50).mean()
            current_price = data['close'].iloc[-1]
            trend_up = current_price > sma_50.iloc[-1]
            
            # Check if TDI trend aligns with price trend
            tdi_trend = tdi_result.get('trend', pd.Series()).iloc[-1] if len(tdi_result.get('trend', pd.Series())) > 0 else 'NEUTRAL'
            filters['trend_confirmation'] = (
                (trend_up and tdi_trend == 'BULLISH') or
                (not trend_up and tdi_trend == 'BEARISH') or
                tdi_trend == 'NEUTRAL'
            )
        else:
            filters['trend_confirmation'] = True
        
        # Volatility filter
        if len(data) >= 20:
            # High volatility periods may produce false signals
            volatility = data['close'].rolling(window=20).std().iloc[-1]
            avg_volatility = data['close'].rolling(window=20).std().rolling(window=10).mean().iloc[-1]
            filters['volatility_filter'] = volatility < (avg_volatility * 2)
        else:
            filters['volatility_filter'] = True
        
        return filters
    
    def calculate_risk_management(self, action: str, current_price: float) -> Dict[str, float]:
        """Calculate stop loss and take profit levels."""
        if action == 'BUY':
            stop_loss = current_price * (1 - self.stop_loss_pct)
            take_profit = current_price * (1 + self.take_profit_pct)
        elif action == 'SELL':
            stop_loss = current_price * (1 + self.stop_loss_pct)
            take_profit = current_price * (1 - self.take_profit_pct)
        else:
            return {'stop_loss': None, 'take_profit': None, 'risk_reward_ratio': None}
        
        risk = abs(current_price - stop_loss)
        reward = abs(take_profit - current_price)
        risk_reward_ratio = reward / risk if risk > 0 else 0
        
        return {
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'risk_reward_ratio': risk_reward_ratio
        }
    
    def calculate_confidence_score(self, alignment: Dict, filters: Dict, tdi_signal: TDISignal, 
                                  bollinger_signal: BollingerSignal) -> float:
        """Calculate overall confidence score for the signal."""
        # Base confidence from alignment
        base_confidence = alignment['alignment_score']
        
        # Indicator confidence weighting
        tdi_confidence = tdi_signal.confidence / 100
        bollinger_confidence = bollinger_signal.confidence / 100
        indicator_confidence = (tdi_confidence + bollinger_confidence) / 2
        
        # Filter confirmation bonus
        filter_score = sum(filters.values()) / len(filters)
        
        # Volatility context (Bollinger squeeze provides higher confidence)
        volatility_bonus = 0.1 if bollinger_signal.squeeze_state == 'SQUEEZE' else 0
        
        # Combine all factors
        total_confidence = (
            base_confidence * 0.4 +
            indicator_confidence * 0.4 +
            filter_score * 0.15 +
            volatility_bonus
        )
        
        return min(total_confidence * 100, 100)  # Convert to percentage and cap at 100
    
    def determine_action(self, alignment: Dict, confidence: float) -> str:
        """Determine the final trading action based on alignment and confidence."""
        if confidence < (self.min_confidence * 100):
            return 'HOLD'
        
        direction = alignment['direction']
        signal_strength = alignment['signal_strength']
        
        if direction == 'BULLISH' and signal_strength > 0.5:
            return 'BUY'
        elif direction == 'BEARISH' and signal_strength > 0.5:
            return 'SELL'
        else:
            return 'HOLD'
    
    def update_signal_history(self, signal: ConsolidatedSignal):
        """Update signal history for trend analysis."""
        self.signal_history.append(signal)
        
        # Keep only recent signals
        if len(self.signal_history) > self.max_history:
            self.signal_history = self.signal_history[-self.max_history:]
    
    def get_recent_signal_stats(self) -> Dict[str, Any]:
        """Get statistics about recent signals."""
        if not self.signal_history:
            return {'total_signals': 0, 'buy_signals': 0, 'sell_signals': 0, 'avg_confidence': 0}
        
        recent_signals = self.signal_history[-20:]  # Last 20 signals
        
        total_signals = len(recent_signals)
        buy_signals = sum(1 for s in recent_signals if s.action == 'BUY')
        sell_signals = sum(1 for s in recent_signals if s.action == 'SELL')
        avg_confidence = sum(s.confidence for s in recent_signals) / total_signals
        
        return {
            'total_signals': total_signals,
            'buy_signals': buy_signals,
            'sell_signals': sell_signals,
            'hold_signals': total_signals - buy_signals - sell_signals,
            'avg_confidence': avg_confidence
        }
    
    def generate_signal(self, data: pd.DataFrame, tdi_result: Dict, bollinger_result: Dict) -> Optional[ConsolidatedSignal]:
        """
        Generate consolidated trading signal from multiple indicators.
        
        Args:
            data: Market data DataFrame
            tdi_result: Super TDI calculation results
            bollinger_result: Super Bollinger calculation results
            
        Returns:
            ConsolidatedSignal or None if no signal should be generated
        """
        try:
            # Get latest signals from indicators
            tdi_signal = tdi_result.get('latest_signal')
            bollinger_signal = bollinger_result.get('latest_signal')
            
            if not tdi_signal or not bollinger_signal:
                return None
            
            current_price = data['close'].iloc[-1]
            timestamp = data.index[-1]
            
            # Calculate signal alignment
            alignment = self.calculate_signal_alignment(tdi_signal, bollinger_signal)
            
            # Apply signal filters
            filters = self.apply_signal_filters(data, tdi_result, bollinger_result)
            
            # Calculate confidence score
            confidence = self.calculate_confidence_score(alignment, filters, tdi_signal, bollinger_signal)
            
            # Determine action
            action = self.determine_action(alignment, confidence)
            
            # Skip if action is HOLD
            if action == 'HOLD':
                return None
            
            # Calculate risk management levels
            risk_mgmt = self.calculate_risk_management(action, current_price)
            
            # Create consolidated signal
            signal = ConsolidatedSignal(
                action=action,
                confidence=confidence,
                strength=alignment['signal_strength'],
                strategy_name=self.config.get('name', 'consolidated_strategy'),
                tdi_signal=tdi_signal.signal,
                bollinger_signal=bollinger_signal.signal,
                price=current_price,
                timestamp=timestamp,
                stop_loss=risk_mgmt['stop_loss'],
                take_profit=risk_mgmt['take_profit'],
                risk_reward_ratio=risk_mgmt['risk_reward_ratio'],
                position_size=self.position_size_pct
            )
            
            # Update signal history
            self.update_signal_history(signal)
            
            return signal
            
        except Exception as e:
            print(f"Error generating consolidated signal: {e}")
            return None
    
    def get_strategy_summary(self) -> Dict[str, Any]:
        """Get summary of strategy performance and configuration."""
        recent_stats = self.get_recent_signal_stats()
        
        return {
            'strategy_name': self.config.get('name', 'consolidated_strategy'),
            'min_confidence': self.min_confidence,
            'risk_reward_ratio': self.risk_reward_ratio,
            'stop_loss_pct': self.stop_loss_pct,
            'take_profit_pct': self.take_profit_pct,
            'recent_signals': recent_stats,
            'total_historical_signals': len(self.signal_history)
        }
