"""
Settings and Configuration Management
Handles loading and validation of configuration parameters.
"""

import os
import yaml
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class TDIConfig:
    """Super TDI indicator configuration with enhanced zone detection."""
    rsi_period: int = 10
    rsi_price_line: int = 2
    rsi_signal_line: int = 7
    rsi_timeframe: int = 1
    band_length: int = 34
    band_mult: float = 1.6185
    momentum_lookback: int = 1
    
    # Enhanced TDI Zones
    hard_buy_zone: float = 25
    soft_buy_zone: float = 35
    no_trade_zone_lower: float = 45
    no_trade_zone_upper: float = 55
    soft_sell_zone: float = 65
    hard_sell_zone: float = 75
    
    # Legacy support
    oversold_level: float = 32
    overbought_level: float = 68


@dataclass
class BollingerConfig:
    """Super Bollinger indicator configuration."""
    length: int = 20
    multiplier: float = 2.0
    ma_type: str = "SMA"
    squeeze_threshold: float = 0.1
    expansion_threshold: float = 0.15


@dataclass
class StrategyConfig:
    """Enhanced strategy configuration with zone-based trading."""
    name: str = "consolidated_trend_strategy"
    min_data_points: int = 50
    confidence_threshold: float = 0.7
    risk_reward_ratio: float = 2.0
    max_positions: int = 3
    
    # Risk management
    stop_loss_pct: float = 0.02
    take_profit_pct: float = 0.04
    position_size_pct: float = 0.1
    risk_per_trade: float = 0.5  # Risk % per trade
    
    # Signal confirmation requirements
    require_ma_crossover: bool = True
    require_bb_rejection: bool = True
    require_volume_confirmation: bool = True
    
    # Zone-based risk factors
    hard_zone_risk_multiplier: float = 2.0  # 2x risk for hard zones
    soft_zone_risk_multiplier: float = 1.0  # 1x risk for soft zones


class Settings:
    """Main settings class that loads and manages all configuration."""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        self.config_path = config_path
        self.config = self._load_config()
        self._validate_config()
        
        # Initialize component configs
        self.tdi_config = TDIConfig(**self.config.get('indicators', {}).get('super_tdi', {}))
        self.bollinger_config = BollingerConfig(**self.config.get('indicators', {}).get('super_bollinger', {}))
        self.strategy_config = StrategyConfig(**self._merge_strategy_config())
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            with open(self.config_path, 'r') as file:
                config = yaml.safe_load(file)
            return config or {}
        except FileNotFoundError:
            print(f"Warning: Config file {self.config_path} not found, using defaults")
            return {}
        except yaml.YAMLError as e:
            raise ValueError(f"Error parsing config file: {e}")
    
    def _merge_strategy_config(self) -> Dict[str, Any]:
        """Merge strategy and risk management configuration."""
        strategy_config = self.config.get('strategy', {})
        risk_config = strategy_config.get('risk_management', {})
        
        # Merge risk management into main strategy config
        merged = {**strategy_config}
        merged.update(risk_config)
        
        return merged
    
    def _validate_config(self):
        """Validate critical configuration parameters."""
        required_env_vars = [
            'TELEGRAM_BOT_TOKEN',
            'TELEGRAM_CHAT_ID',
        ]
        
        missing_vars = []
        for var in required_env_vars:
            if not os.getenv(var):
                missing_vars.append(var)
        
        if missing_vars:
            raise ValueError(f"Missing required environment variables: {missing_vars}")
    
    @property
    def telegram_token(self) -> str:
        """Get Telegram bot token from environment."""
        return os.getenv('TELEGRAM_BOT_TOKEN', '')
    
    @property
    def telegram_chat_id(self) -> str:
        """Get Telegram chat ID from environment."""
        return os.getenv('TELEGRAM_CHAT_ID', '')
    
    @property
    def binance_api_key(self) -> str:
        """Get Binance API key from environment."""
        return os.getenv('BINANCE_API_KEY', '')
    
    @property
    def binance_secret_key(self) -> str:
        """Get Binance secret key from environment."""
        return os.getenv('BINANCE_SECRET_KEY', '')
    
    @property
    def log_level(self) -> str:
        """Get logging level."""
        return self.config.get('logging', {}).get('level', 'INFO')
    
    @property
    def log_file(self) -> str:
        """Get log file path."""
        return self.config.get('logging', {}).get('file', 'logs/trading_bot.log')
    
    @property
    def trading_config(self) -> Dict[str, Any]:
        """Get trading configuration."""
        return self.config.get('trading', {
            'symbols': ['BTCUSDT'],
            'analysis_interval': 300,
            'paper_trading': True
        })
    
    @property
    def data_config(self) -> Dict[str, Any]:
        """Get data configuration."""
        return self.config.get('data', {
            'source': 'binance',
            'timeframe': '5m',
            'lookback_periods': 200,
            'cache_duration': 300
        })
    
    @property
    def database_config(self) -> Dict[str, Any]:
        """Get database configuration."""
        return self.config.get('database', {
            'type': 'sqlite',
            'path': 'data/trading_bot.db'
        })
    
    @property
    def api_config(self) -> Dict[str, Any]:
        """Get API configuration."""
        return self.config.get('api', {})
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key."""
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """Set configuration value by key."""
        keys = key.split('.')
        config = self.config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def save(self, path: Optional[str] = None):
        """Save configuration to file."""
        if path is None:
            path = self.config_path
        
        with open(path, 'w') as file:
            yaml.dump(self.config, file, default_flow_style=False, indent=2)
