# Historical Data Directory

This directory stores historical market data for backtesting and analysis.

## Structure

