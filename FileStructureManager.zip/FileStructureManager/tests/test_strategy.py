"""
Test Suite for Trading Strategy
Tests for ConsolidatedStrategy and related components.
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from unittest.mock import Mock, MagicMock

from src.strategy.consolidated_strategy import ConsolidatedStrategy, ConsolidatedSignal
from src.indicators.super_tdi import SuperTDI, TDISignal
from src.indicators.super_bollinger import SuperBollinger, BollingerSignal
from config.settings import TDIConfig, BollingerConfig


class TestConsolidatedStrategy:
    """Test cases for ConsolidatedStrategy."""
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2024-01-01', periods=100, freq='5T')
        np.random.seed(42)
        
        base_price = 50000
        returns = np.random.normal(0, 0.01, 100)
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        data = pd.DataFrame({
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.005))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.005))) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000, 5000, 100)
        }, index=dates)
        
        return data
    
    @pytest.fixture
    def mock_indicators(self):
        """Create mock indicators for testing."""
        tdi_mock = Mock(spec=SuperTDI)
        bollinger_mock = Mock(spec=SuperBollinger)
        return tdi_mock, bollinger_mock
    
    @pytest.fixture
    def strategy_config(self):
        """Create strategy configuration for testing."""
        return {
            'name': 'test_strategy',
            'confidence_threshold': 0.7,
            'risk_reward_ratio': 2.0,
            'stop_loss_pct': 0.02,
            'take_profit_pct': 0.04,
            'position_size_pct': 0.1,
            'min_data_points': 50
        }
    
    @pytest.fixture
    def strategy(self, mock_indicators, strategy_config):
        """Create ConsolidatedStrategy instance for testing."""
        tdi_mock, bollinger_mock = mock_indicators
        return ConsolidatedStrategy(tdi_mock, bollinger_mock, strategy_config)
    
    @pytest.fixture
    def sample_tdi_signal(self):
        """Create sample TDI signal."""
        return TDISignal(
            signal='BUY',
            strength=0.8,
            rsi_value=35.0,
            rsi_ma=40.0,
            rsi_signal=45.0,
            volatility_band_upper=70.0,
            volatility_band_lower=30.0,
            momentum=2.5,
            trend_direction='BULLISH',
            confidence=75.0
        )
    
    @pytest.fixture
    def sample_bollinger_signal(self):
        """Create sample Bollinger signal."""
        return BollingerSignal(
            signal='BUY',
            strength=0.7,
            price_position=-0.8,
            bandwidth=5.2,
            squeeze_state='EXPANSION',
            volatility_trend='INCREASING',
            confidence=70.0
        )
    
    def test_strategy_initialization(self, mock_indicators, strategy_config):
        """Test strategy initialization."""
        tdi_mock, bollinger_mock = mock_indicators
        strategy = ConsolidatedStrategy(tdi_mock, bollinger_mock, strategy_config)
        
        assert strategy.tdi == tdi_mock
        assert strategy.bollinger == bollinger_mock
        assert strategy.config == strategy_config
        assert strategy.min_confidence == 0.7
        assert strategy.risk_reward_ratio == 2.0
        assert strategy.stop_loss_pct == 0.02
        assert strategy.take_profit_pct == 0.04
        assert strategy.position_size_pct == 0.1
    
    def test_signal_alignment_bullish(self, strategy, sample_tdi_signal, sample_bollinger_signal):
        """Test signal alignment calculation for bullish signals."""
        alignment = strategy.calculate_signal_alignment(sample_tdi_signal, sample_bollinger_signal)
        
        assert alignment['direction'] == 'BULLISH'
        assert alignment['alignment_score'] > 0
        assert alignment['tdi_value'] > 0
        assert alignment['bollinger_value'] > 0
        assert alignment['signal_strength'] > 0
    
    def test_signal_alignment_conflicting(self, strategy, sample_tdi_signal, sample_bollinger_signal):
        """Test signal alignment for conflicting signals."""
        # Make bollinger signal bearish
        sample_bollinger_signal.signal = 'SELL'
        
        alignment = strategy.calculate_signal_alignment(sample_tdi_signal, sample_bollinger_signal)
        
        assert alignment['direction'] == 'NEUTRAL'
        assert alignment['alignment_score'] == 0.2  # Low confidence for conflicting signals
    
    def test_signal_filters(self, strategy, sample_data):
        """Test signal filtering."""
        # Create mock indicator results
        tdi_result = {'trend': pd.Series(['BULLISH'] * len(sample_data), index=sample_data.index)}
        bollinger_result = {}
        
        filters = strategy.apply_signal_filters(sample_data, tdi_result, bollinger_result)
        
        # Should have all required filter keys
        expected_filters = ['volume_confirmation', 'trend_confirmation', 'volatility_filter']
        for filter_name in expected_filters:
            assert filter_name in filters
            assert isinstance(filters[filter_name], bool)
    
    def test_risk_management_buy(self, strategy):
        """Test risk management calculations for buy signal."""
        current_price = 50000
        risk_mgmt = strategy.calculate_risk_management('BUY', current_price)
        
        expected_stop_loss = current_price * (1 - strategy.stop_loss_pct)
        expected_take_profit = current_price * (1 + strategy.take_profit_pct)
        
        assert risk_mgmt['stop_loss'] == expected_stop_loss
        assert risk_mgmt['take_profit'] == expected_take_profit
        assert risk_mgmt['risk_reward_ratio'] == pytest.approx(2.0, rel=0.1)
    
    def test_risk_management_sell(self, strategy):
        """Test risk management calculations for sell signal."""
        current_price = 50000
        risk_mgmt = strategy.calculate_risk_management('SELL', current_price)
        
        expected_stop_loss = current_price * (1 + strategy.stop_loss_pct)
        expected_take_profit = current_price * (1 - strategy.take_profit_pct)
        
        assert risk_mgmt['stop_loss'] == expected_stop_loss
        assert risk_mgmt['take_profit'] == expected_take_profit
        assert risk_mgmt['risk_reward_ratio'] == pytest.approx(2.0, rel=0.1)
    
    def test_risk_management_hold(self, strategy):
        """Test risk management for hold signal."""
        risk_mgmt = strategy.calculate_risk_management('HOLD', 50000)
        
        assert risk_mgmt['stop_loss'] is None
        assert risk_mgmt['take_profit'] is None
        assert risk_mgmt['risk_reward_ratio'] is None
    
    def test_confidence_calculation(self, strategy, sample_tdi_signal, sample_bollinger_signal):
        """Test confidence score calculation."""
        alignment = {'alignment_score': 0.8, 'signal_strength': 0.7}
        filters = {'volume_confirmation': True, 'trend_confirmation': True, 'volatility_filter': True}
        
        confidence = strategy.calculate_confidence_score(
            alignment, filters, sample_tdi_signal, sample_bollinger_signal
        )
        
        assert 0 <= confidence <= 100
        assert isinstance(confidence, float)
    
    def test_action_determination_high_confidence(self, strategy):
        """Test action determination with high confidence."""
        alignment = {'direction': 'BULLISH', 'signal_strength': 0.8}
        confidence = 80.0  # Above threshold
        
        action = strategy.determine_action(alignment, confidence)
        assert action == 'BUY'
        
        alignment = {'direction': 'BEARISH', 'signal_strength': 0.8}
        action = strategy.determine_action(alignment, confidence)
        assert action == 'SELL'
    
    def test_action_determination_low_confidence(self, strategy):
        """Test action determination with low confidence."""
        alignment = {'direction': 'BULLISH', 'signal_strength': 0.8}
        confidence = 50.0  # Below threshold
        
        action = strategy.determine_action(alignment, confidence)
        assert action == 'HOLD'
    
    def test_signal_generation_success(self, strategy, sample_data, sample_tdi_signal, sample_bollinger_signal):
        """Test successful signal generation."""
        # Create mock indicator results
        tdi_result = {
            'latest_signal': sample_tdi_signal,
            'trend': pd.Series(['BULLISH'] * len(sample_data), index=sample_data.index)
        }
        bollinger_result = {
            'latest_signal': sample_bollinger_signal
        }
        
        signal = strategy.generate_signal(sample_data, tdi_result, bollinger_result)
        
        if signal:  # Signal might be None if confidence is too low
            assert isinstance(signal, ConsolidatedSignal)
            assert signal.action in ['BUY', 'SELL']
            assert 0 <= signal.confidence <= 100
            assert signal.strategy_name == strategy.config['name']
            assert signal.stop_loss is not None
            assert signal.take_profit is not None
    
    def test_signal_generation_no_indicator_signals(self, strategy, sample_data):
        """Test signal generation when indicator signals are missing."""
        tdi_result = {'latest_signal': None}
        bollinger_result = {'latest_signal': None}
        
        signal = strategy.generate_signal(sample_data, tdi_result, bollinger_result)
        assert signal is None
    
    def test_signal_history_management(self, strategy):
        """Test signal history management."""
        # Create multiple mock signals
        for i in range(150):  # More than max_history
            mock_signal = ConsolidatedSignal(
                action='BUY',
                confidence=75.0,
                strength=0.8,
                strategy_name='test',
                tdi_signal='BUY',
                bollinger_signal='BUY',
                price=50000,
                timestamp=datetime.now() + timedelta(minutes=i)
            )
            strategy.update_signal_history(mock_signal)
        
        # Should not exceed max_history
        assert len(strategy.signal_history) <= strategy.max_history
        assert len(strategy.signal_history) == strategy.max_history
    
    def test_recent_signal_stats(self, strategy):
        """Test recent signal statistics calculation."""
        # Add various signals
        signals = [
            ('BUY', 80.0), ('SELL', 75.0), ('BUY', 70.0), ('HOLD', 60.0), ('SELL', 85.0)
        ]
        
        for action, confidence in signals:
            mock_signal = ConsolidatedSignal(
                action=action,
                confidence=confidence,
                strength=0.8,
                strategy_name='test',
                tdi_signal=action,
                bollinger_signal=action,
                price=50000,
                timestamp=datetime.now()
            )
            strategy.update_signal_history(mock_signal)
        
        stats = strategy.get_recent_signal_stats()
        
        assert stats['total_signals'] == 5
        assert stats['buy_signals'] == 2
        assert stats['sell_signals'] == 2
        assert stats['hold_signals'] == 1
        assert 60 <= stats['avg_confidence'] <= 85
    
    def test_strategy_summary(self, strategy):
        """Test strategy summary generation."""
        summary = strategy.get_strategy_summary()
        
        required_keys = [
            'strategy_name', 'min_confidence', 'risk_reward_ratio',
            'stop_loss_pct', 'take_profit_pct', 'recent_signals',
            'total_historical_signals'
        ]
        
        for key in required_keys:
            assert key in summary
        
        assert summary['strategy_name'] == strategy.config['name']
        assert summary['min_confidence'] == strategy.min_confidence
        assert summary['risk_reward_ratio'] == strategy.risk_reward_ratio


class TestConsolidatedSignal:
    """Test cases for ConsolidatedSignal data structure."""
    
    def test_consolidated_signal_creation(self):
        """Test ConsolidatedSignal creation."""
        timestamp = datetime.now()
        
        signal = ConsolidatedSignal(
            action='BUY',
            confidence=75.0,
            strength=0.8,
            strategy_name='test_strategy',
            tdi_signal='BUY',
            bollinger_signal='BUY',
            price=50000.0,
            timestamp=timestamp,
            stop_loss=49000.0,
            take_profit=52000.0,
            risk_reward_ratio=2.0,
            position_size=0.1
        )
        
        assert signal.action == 'BUY'
        assert signal.confidence == 75.0
        assert signal.strength == 0.8
        assert signal.strategy_name == 'test_strategy'
        assert signal.tdi_signal == 'BUY'
        assert signal.bollinger_signal == 'BUY'
        assert signal.price == 50000.0
        assert signal.timestamp == timestamp
        assert signal.stop_loss == 49000.0
        assert signal.take_profit == 52000.0
        assert signal.risk_reward_ratio == 2.0
        assert signal.position_size == 0.1
    
    def test_consolidated_signal_defaults(self):
        """Test ConsolidatedSignal with default values."""
        signal = ConsolidatedSignal(
            action='HOLD',
            confidence=50.0,
            strength=0.5,
            strategy_name='test',
            tdi_signal='HOLD',
            bollinger_signal='HOLD',
            price=50000.0,
            timestamp=datetime.now()
        )
        
        assert signal.stop_loss is None
        assert signal.take_profit is None
        assert signal.risk_reward_ratio is None
        assert signal.position_size is None


class TestStrategyIntegration:
    """Integration tests for strategy with real indicators."""
    
    @pytest.fixture
    def real_strategy(self):
        """Create strategy with real indicator instances."""
        tdi_config = TDIConfig()
        bollinger_config = BollingerConfig()
        strategy_config = {
            'name': 'integration_test',
            'confidence_threshold': 0.6,
            'risk_reward_ratio': 2.0,
            'stop_loss_pct': 0.02,
            'take_profit_pct': 0.04,
            'position_size_pct': 0.1,
            'min_data_points': 50
        }
        
        tdi = SuperTDI(tdi_config)
        bollinger = SuperBollinger(bollinger_config)
        
        return ConsolidatedStrategy(tdi, bollinger, strategy_config)
    
    @pytest.fixture
    def trending_data(self):
        """Create trending market data for integration tests."""
        dates = pd.date_range(start='2024-01-01', periods=200, freq='5T')
        np.random.seed(42)
        
        # Create strong uptrend
        base_price = 50000
        trend = np.linspace(0, 0.3, 200)  # 30% uptrend
        noise = np.random.normal(0, 0.005, 200)  # 0.5% noise
        
        prices = []
        for i in range(200):
            price = base_price * (1 + trend[i] + noise[i])
            prices.append(price)
        
        data = pd.DataFrame({
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.003))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.003))) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000, 5000, 200)
        }, index=dates)
        
        return data
    
    def test_strategy_with_real_indicators(self, real_strategy, trending_data):
        """Test strategy integration with real indicators."""
        # Calculate indicators
        tdi_result = real_strategy.tdi.calculate(trending_data)
        bollinger_result = real_strategy.bollinger.calculate(trending_data)
        
        # Generate signal
        signal = real_strategy.generate_signal(trending_data, tdi_result, bollinger_result)
        
        # Should generate a signal on trending data
        if signal:
            assert isinstance(signal, ConsolidatedSignal)
            assert signal.action in ['BUY', 'SELL']
            assert 0 <= signal.confidence <= 100
            assert signal.stop_loss is not None
            assert signal.take_profit is not None
            assert signal.price > 0
    
    def test_strategy_signal_consistency(self, real_strategy, trending_data):
        """Test that strategy produces consistent signals."""
        signals = []
        
        # Generate signals for multiple time windows
        for i in range(60, len(trending_data), 10):
            window_data = trending_data.iloc[:i]
            tdi_result = real_strategy.tdi.calculate(window_data)
            bollinger_result = real_strategy.bollinger.calculate(window_data)
            
            signal = real_strategy.generate_signal(window_data, tdi_result, bollinger_result)
            if signal:
                signals.append(signal)
        
        # Should have generated some signals
        assert len(signals) > 0
        
        # Signals should be logically consistent for trending data
        buy_signals = [s for s in signals if s.action == 'BUY']
        sell_signals = [s for s in signals if s.action == 'SELL']
        
        # In a strong uptrend, should have more buy signals
        if len(buy_signals) > 0 or len(sell_signals) > 0:
            assert len(buy_signals) >= len(sell_signals)


if __name__ == '__main__':
    pytest.main([__file__])
