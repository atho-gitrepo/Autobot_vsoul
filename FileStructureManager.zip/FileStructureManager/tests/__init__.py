"""
Test Suite for Trading Bot
Contains comprehensive tests for all components of the algorithmic trading bot.
"""

import pytest
import logging

# Configure logging for tests
logging.basicConfig(
    level=logging.WARNING,  # Reduce noise during tests
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Suppress third-party library logs during testing
logging.getLogger('urllib3').setLevel(logging.ERROR)
logging.getLogger('aiohttp').setLevel(logging.ERROR)
logging.getLogger('asyncio').setLevel(logging.ERROR)

__all__ = []
