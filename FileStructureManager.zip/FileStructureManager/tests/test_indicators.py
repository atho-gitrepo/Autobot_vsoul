"""
Test Suite for Technical Indicators
Tests for Super TDI and Super Bollinger indicators.
"""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from unittest.mock import Mock, patch

from src.indicators.super_tdi import SuperTDI, TDISignal
from src.indicators.super_bollinger import SuperBollinger, BollingerSignal
from config.settings import TDIConfig, BollingerConfig


class TestSuperTDI:
    """Test cases for Super TDI indicator."""
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2024-01-01', periods=100, freq='5T')
        np.random.seed(42)  # For reproducible tests
        
        # Generate realistic price data
        base_price = 50000
        returns = np.random.normal(0, 0.01, 100)
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        data = pd.DataFrame({
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.005))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.005))) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000, 5000, 100)
        }, index=dates)
        
        # Ensure OHLC logic
        for i in range(len(data)):
            data.loc[data.index[i], 'high'] = max(
                data.loc[data.index[i], 'open'],
                data.loc[data.index[i], 'high'],
                data.loc[data.index[i], 'close']
            )
            data.loc[data.index[i], 'low'] = min(
                data.loc[data.index[i], 'open'],
                data.loc[data.index[i], 'low'],
                data.loc[data.index[i], 'close']
            )
        
        return data
    
    @pytest.fixture
    def tdi_config(self):
        """Create TDI configuration for testing."""
        return TDIConfig(
            rsi_period=13,
            rsi_price_line=2,
            rsi_signal_line=7,
            band_length=34,
            band_mult=1.6185,
            oversold_level=32,
            overbought_level=68
        )
    
    def test_tdi_initialization(self, tdi_config):
        """Test TDI indicator initialization."""
        tdi = SuperTDI(tdi_config)
        
        assert tdi.rsi_period == 13
        assert tdi.rsi_price_line == 2
        assert tdi.rsi_signal_line == 7
        assert tdi.oversold_level == 32
        assert tdi.overbought_level == 68
    
    def test_rsi_calculation(self, tdi_config, sample_data):
        """Test RSI calculation."""
        tdi = SuperTDI(tdi_config)
        rsi = tdi.calculate_rsi(sample_data['close'], 14)
        
        assert len(rsi) == len(sample_data)
        assert not rsi.isnull().all()
        assert (rsi >= 0).all()
        assert (rsi <= 100).all()
    
    def test_sma_calculation(self, tdi_config):
        """Test Simple Moving Average calculation."""
        tdi = SuperTDI(tdi_config)
        data = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        sma = tdi.calculate_sma(data, 3)
        
        expected = pd.Series([1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0])
        pd.testing.assert_series_equal(sma, expected, check_names=False)
    
    def test_bollinger_bands_calculation(self, tdi_config, sample_data):
        """Test Bollinger Bands calculation for TDI."""
        tdi = SuperTDI(tdi_config)
        rsi = tdi.calculate_rsi(sample_data['close'], 14)
        
        upper, lower, middle = tdi.calculate_bollinger_bands(rsi, 20, 2.0)
        
        assert len(upper) == len(rsi)
        assert len(lower) == len(rsi)
        assert len(middle) == len(rsi)
        assert (upper >= middle).all()
        assert (lower <= middle).all()
    
    def test_momentum_calculation(self, tdi_config, sample_data):
        """Test momentum calculation."""
        tdi = SuperTDI(tdi_config)
        rsi = tdi.calculate_rsi(sample_data['close'], 14)
        momentum = tdi.calculate_momentum(rsi, 1)
        
        assert len(momentum) == len(rsi)
        # First value should be NaN due to diff operation
        assert pd.isnull(momentum.iloc[0])
    
    def test_trend_determination(self, tdi_config, sample_data):
        """Test trend determination logic."""
        tdi = SuperTDI(tdi_config)
        rsi = tdi.calculate_rsi(sample_data['close'], 14)
        rsi_ma = tdi.calculate_sma(rsi, 2)
        rsi_signal = tdi.calculate_sma(rsi_ma, 7)
        
        trend = tdi.determine_trend(rsi_ma, rsi_signal)
        
        assert len(trend) == len(rsi)
        assert all(t in ['BULLISH', 'BEARISH', 'NEUTRAL'] for t in trend)
    
    def test_full_calculation(self, tdi_config, sample_data):
        """Test full TDI calculation."""
        tdi = SuperTDI(tdi_config)
        result = tdi.calculate(sample_data)
        
        # Check all required keys are present
        required_keys = ['signals', 'rsi', 'rsi_ma', 'rsi_signal', 'upper_band', 
                        'lower_band', 'momentum', 'trend', 'strength', 'latest_signal']
        for key in required_keys:
            assert key in result
        
        # Check latest signal
        if result['latest_signal']:
            assert isinstance(result['latest_signal'], TDISignal)
            assert result['latest_signal'].signal in ['BUY', 'SELL', 'HOLD', 'STRONG_BUY', 'STRONG_SELL']
            assert 0 <= result['latest_signal'].confidence <= 100
    
    def test_insufficient_data(self, tdi_config):
        """Test behavior with insufficient data."""
        tdi = SuperTDI(tdi_config)
        
        # Create minimal data (less than required periods)
        dates = pd.date_range(start='2024-01-01', periods=5, freq='5T')
        small_data = pd.DataFrame({
            'open': [100, 101, 102, 103, 104],
            'high': [101, 102, 103, 104, 105],
            'low': [99, 100, 101, 102, 103],
            'close': [100.5, 101.5, 102.5, 103.5, 104.5],
            'volume': [1000, 1100, 1200, 1300, 1400]
        }, index=dates)
        
        result = tdi.calculate(small_data)
        
        # Should return empty series for most indicators
        assert len(result['signals']) == 0
        assert result['latest_signal'] is None
    
    def test_signal_descriptions(self, tdi_config):
        """Test signal description mapping."""
        tdi = SuperTDI(tdi_config)
        
        signals = ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL']
        for signal in signals:
            description = tdi.get_signal_description(signal)
            assert isinstance(description, str)
            assert len(description) > 0


class TestSuperBollinger:
    """Test cases for Super Bollinger indicator."""
    
    @pytest.fixture
    def sample_data(self):
        """Create sample OHLCV data for testing."""
        dates = pd.date_range(start='2024-01-01', periods=100, freq='5T')
        np.random.seed(42)
        
        base_price = 50000
        returns = np.random.normal(0, 0.01, 100)
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        data = pd.DataFrame({
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.005))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.005))) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000, 5000, 100)
        }, index=dates)
        
        return data
    
    @pytest.fixture
    def bollinger_config(self):
        """Create Bollinger configuration for testing."""
        return BollingerConfig(
            length=20,
            multiplier=2.0,
            ma_type="SMA",
            squeeze_threshold=0.1,
            expansion_threshold=0.15
        )
    
    def test_bollinger_initialization(self, bollinger_config):
        """Test Bollinger indicator initialization."""
        bollinger = SuperBollinger(bollinger_config)
        
        assert bollinger.length == 20
        assert bollinger.multiplier == 2.0
        assert bollinger.ma_type == "SMA"
        assert bollinger.squeeze_threshold == 0.1
        assert bollinger.expansion_threshold == 0.15
    
    def test_moving_average_sma(self, bollinger_config):
        """Test SMA calculation."""
        bollinger = SuperBollinger(bollinger_config)
        data = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        
        sma = bollinger.calculate_moving_average(data, 3, "SMA")
        expected = pd.Series([1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0])
        pd.testing.assert_series_equal(sma, expected, check_names=False)
    
    def test_moving_average_ema(self, bollinger_config):
        """Test EMA calculation."""
        bollinger = SuperBollinger(bollinger_config)
        data = pd.Series([1, 2, 3, 4, 5])
        
        ema = bollinger.calculate_moving_average(data, 3, "EMA")
        
        assert len(ema) == len(data)
        assert not ema.isnull().any()
        # EMA should be smoother than SMA
        assert ema.iloc[-1] != data.rolling(3).mean().iloc[-1]
    
    def test_bollinger_bands_calculation(self, bollinger_config, sample_data):
        """Test Bollinger Bands calculation."""
        bollinger = SuperBollinger(bollinger_config)
        upper, middle, lower, std_dev = bollinger.calculate_bollinger_bands(sample_data['close'])
        
        assert len(upper) == len(sample_data)
        assert len(middle) == len(sample_data)
        assert len(lower) == len(sample_data)
        assert (upper >= middle).all()
        assert (lower <= middle).all()
        assert (std_dev >= 0).all()
    
    def test_bandwidth_calculation(self, bollinger_config, sample_data):
        """Test bandwidth calculation."""
        bollinger = SuperBollinger(bollinger_config)
        upper, middle, lower, _ = bollinger.calculate_bollinger_bands(sample_data['close'])
        
        bandwidth = bollinger.calculate_bandwidth(upper, lower, middle)
        
        assert len(bandwidth) == len(sample_data)
        assert (bandwidth >= 0).all()
    
    def test_percent_b_calculation(self, bollinger_config, sample_data):
        """Test %B calculation."""
        bollinger = SuperBollinger(bollinger_config)
        upper, middle, lower, _ = bollinger.calculate_bollinger_bands(sample_data['close'])
        
        percent_b = bollinger.calculate_percent_b(sample_data['close'], upper, lower)
        
        assert len(percent_b) == len(sample_data)
        # %B should be between 0 and 1 for prices within bands
        # (can be outside this range for prices outside bands)
    
    def test_squeeze_detection(self, bollinger_config, sample_data):
        """Test squeeze detection."""
        bollinger = SuperBollinger(bollinger_config)
        upper, middle, lower, _ = bollinger.calculate_bollinger_bands(sample_data['close'])
        bandwidth = bollinger.calculate_bandwidth(upper, lower, middle)
        
        squeeze_state = bollinger.detect_squeeze(bandwidth)
        
        assert len(squeeze_state) == len(sample_data)
        assert all(state in ['SQUEEZE', 'EXPANSION', 'NORMAL'] for state in squeeze_state)
    
    def test_full_calculation(self, bollinger_config, sample_data):
        """Test full Bollinger calculation."""
        bollinger = SuperBollinger(bollinger_config)
        result = bollinger.calculate(sample_data)
        
        # Check all required keys are present
        required_keys = ['signals', 'upper', 'middle', 'lower', 'bandwidth', 
                        'percent_b', 'price_position', 'squeeze_state', 
                        'volatility_trend', 'strength', 'latest_signal']
        for key in required_keys:
            assert key in result
        
        # Check latest signal
        if result['latest_signal']:
            assert isinstance(result['latest_signal'], BollingerSignal)
            signal_types = ['BUY', 'SELL', 'HOLD', 'STRONG_BUY', 'STRONG_SELL', 
                           'BREAKOUT_BUY', 'BREAKOUT_SELL']
            assert result['latest_signal'].signal in signal_types
            assert 0 <= result['latest_signal'].confidence <= 100
    
    def test_insufficient_data(self, bollinger_config):
        """Test behavior with insufficient data."""
        bollinger = SuperBollinger(bollinger_config)
        
        dates = pd.date_range(start='2024-01-01', periods=5, freq='5T')
        small_data = pd.DataFrame({
            'open': [100, 101, 102, 103, 104],
            'high': [101, 102, 103, 104, 105],
            'low': [99, 100, 101, 102, 103],
            'close': [100.5, 101.5, 102.5, 103.5, 104.5],
            'volume': [1000, 1100, 1200, 1300, 1400]
        }, index=dates)
        
        result = bollinger.calculate(small_data)
        
        # Should return empty series for most indicators
        assert len(result['signals']) == 0
        assert result['latest_signal'] is None
    
    def test_signal_descriptions(self, bollinger_config):
        """Test signal description mapping."""
        bollinger = SuperBollinger(bollinger_config)
        
        signals = ['STRONG_BUY', 'BUY', 'BREAKOUT_BUY', 'HOLD', 
                  'SELL', 'BREAKOUT_SELL', 'STRONG_SELL']
        for signal in signals:
            description = bollinger.get_signal_description(signal)
            assert isinstance(description, str)
            assert len(description) > 0


class TestIndicatorIntegration:
    """Integration tests for indicators working together."""
    
    @pytest.fixture
    def sample_data(self):
        """Create sample data for integration tests."""
        dates = pd.date_range(start='2024-01-01', periods=200, freq='5T')
        np.random.seed(42)
        
        # Create trending data
        base_price = 50000
        trend = np.linspace(0, 0.2, 200)  # 20% uptrend
        noise = np.random.normal(0, 0.01, 200)  # 1% noise
        
        prices = [base_price * (1 + trend[0] + noise[0])]
        for i in range(1, 200):
            prices.append(base_price * (1 + trend[i] + noise[i]))
        
        data = pd.DataFrame({
            'open': prices,
            'high': [p * (1 + abs(np.random.normal(0, 0.005))) for p in prices],
            'low': [p * (1 - abs(np.random.normal(0, 0.005))) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000, 5000, 200)
        }, index=dates)
        
        return data
    
    def test_indicators_produce_signals(self, sample_data):
        """Test that both indicators produce signals on trending data."""
        tdi_config = TDIConfig()
        bollinger_config = BollingerConfig()
        
        tdi = SuperTDI(tdi_config)
        bollinger = SuperBollinger(bollinger_config)
        
        tdi_result = tdi.calculate(sample_data)
        bollinger_result = bollinger.calculate(sample_data)
        
        # Both should produce some signals
        tdi_signals = tdi_result['signals']
        bollinger_signals = bollinger_result['signals']
        
        assert len(tdi_signals) > 0
        assert len(bollinger_signals) > 0
        
        # Should have non-HOLD signals
        tdi_non_hold = tdi_signals[tdi_signals != 'HOLD']
        bollinger_non_hold = bollinger_signals[bollinger_signals != 'HOLD']
        
        assert len(tdi_non_hold) > 0
        assert len(bollinger_non_hold) > 0
    
    def test_signal_timing_alignment(self, sample_data):
        """Test that signals are properly time-aligned."""
        tdi_config = TDIConfig()
        bollinger_config = BollingerConfig()
        
        tdi = SuperTDI(tdi_config)
        bollinger = SuperBollinger(bollinger_config)
        
        tdi_result = tdi.calculate(sample_data)
        bollinger_result = bollinger.calculate(sample_data)
        
        # Signals should have same index
        assert tdi_result['signals'].index.equals(bollinger_result['signals'].index)
        assert len(tdi_result['signals']) == len(bollinger_result['signals'])


if __name__ == '__main__':
    pytest.main([__file__])
